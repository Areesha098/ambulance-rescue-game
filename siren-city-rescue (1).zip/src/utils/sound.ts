/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  private sirenOsc1: OscillatorNode | null = null;
  private sirenGain: GainNode | null = null;
  private sirenLfo: OscillatorNode | null = null;
  private sirenLfoGain: GainNode | null = null;
  private sirenMode: "wail" | "yelp" | "phaser" | "hilo" = "wail";
  private isSirenActive: boolean = false;
  private isMuted: boolean = false;
  private sirenVolume: number = 0.5; // Configurable siren volume (0.0 to 1.0)

  // Engine Sound Nodes
  private engineOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private isEngineActive: boolean = false;

  // Audio File Elements for loading a physical siren file
  private audioFilePath: string = "/src/assets/sounds/siren.mp3";
  private audioHtmlElement: HTMLAudioElement | null = null;
  private useAudioFile: boolean = false;

  // Public domain or CC0 fallback emergency siren audio files
  private backupSirenUrls: string[] = [
    "https://upload.wikimedia.org/wikipedia/commons/3/30/Ambulance_Siren_in_UK.ogg",
    "https://upload.wikimedia.org/wikipedia/commons/2/23/Ambulance_siren_-_France.ogg",
    "https://upload.wikimedia.org/wikipedia/commons/e/ea/Emergency_siren_single_burst.ogg",
    "https://assets.mixkit.co/active_storage/sfx/2197/2197-84.wav"
  ];
  private currentBackupIndex: number = -1;

  constructor() {
    if (typeof window !== "undefined") {
      // 1. Setup preloaded HTMLAudioElement with event handlers
      this.loadAudioFile();

      // 2. Interactive handler to proactively resume and unlock audio systems in all browsers
      const resumeAudio = () => {
        this.init();

        // Unlock HTMLAudioElement autoplay restrictions on first gesture
        if (this.audioHtmlElement) {
          this.audioHtmlElement.play()
            .then(() => {
              // Immediately pause if the siren shouldn't be playing yet
              if (!this.isSirenActive || this.isMuted) {
                this.audioHtmlElement?.pause();
              }
            })
            .catch(() => {
              // Quietly ignore if not allowed yet
            });
        }

        if (this.ctx && this.ctx.state === "suspended") {
          this.ctx.resume().then(() => {
            // Re-trigger active sounds once context becomes running
            if (this.isSirenActive && !this.isMuted) {
              this.startSiren();
            }
            if (this.isEngineActive && !this.isMuted) {
              this.startEngine();
            }
          }).catch((err) => console.warn("AudioContext resume failed:", err));
        }
      };

      // Register interaction triggers
      window.addEventListener("click", resumeAudio, { once: true });
      window.addEventListener("keydown", resumeAudio, { once: true });
      window.addEventListener("touchstart", resumeAudio, { once: true });
      window.addEventListener("mousedown", resumeAudio, { once: true });
    }
  }

  // Preloads and verifies the siren audio file path, with automatic public domain fallback chain on missing file
  public loadAudioFile(path?: string) {
    if (path) {
      this.audioFilePath = path;
    }

    if (typeof window === "undefined") return;

    try {
      if (!this.audioHtmlElement) {
        this.audioHtmlElement = new Audio();
        this.audioHtmlElement.crossOrigin = "anonymous";
      }
      this.audioHtmlElement.src = this.audioFilePath;
      this.audioHtmlElement.loop = true;

      this.audioHtmlElement.oncanplaythrough = () => {
        console.log(`Siren audio file loaded successfully: ${this.audioHtmlElement?.src}`);
        this.useAudioFile = true;
      };

      this.audioHtmlElement.onerror = () => {
        this.currentBackupIndex++;
        if (this.currentBackupIndex < this.backupSirenUrls.length) {
          const nextUrl = this.backupSirenUrls[this.currentBackupIndex];
          console.info(`Primary/prior siren file missing or failed. Loading public domain / CC0 fallback: ${nextUrl}`);
          if (this.audioHtmlElement) {
            this.audioHtmlElement.src = nextUrl;
            this.audioHtmlElement.load();
          }
        } else {
          // Safe, seamless fallback to pure Web Audio synthesis if all fail or offline
          console.info("All primary and public domain emergency siren files failed/missing. Using high-fidelity Web Audio synthesis.");
          this.useAudioFile = false;
        }
      };

      this.audioHtmlElement.volume = this.sirenVolume * 0.15;
    } catch (e) {
      console.warn("Failed to set up siren audio file:", e);
      this.useAudioFile = false;
    }
  }

  private init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch((e) => console.warn("AudioContext resume failure:", e));
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stopSiren();
      this.stopEngine();
    } else {
      if (this.isSirenActive) {
        this.startSiren();
      }
      if (this.isEngineActive) {
        this.startEngine();
      }
    }
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.setMute(!this.isMuted);
    return this.isMuted;
  }

  public setVolume(volume: number) {
    this.sirenVolume = Math.max(0, Math.min(1, volume));
    if (this.audioHtmlElement) {
      this.audioHtmlElement.volume = this.sirenVolume * 0.15;
    }
    if (this.sirenGain && this.ctx) {
      const now = this.ctx.currentTime;
      this.sirenGain.gain.setValueAtTime(0.026 * this.sirenVolume * 2, now);
    }
  }

  // Plays a short synth note
  private playTone(
    freqs: number[],
    durations: number[],
    type: OscillatorType = "sine",
    gainStart = 0.15,
    glide = false
  ) {
    this.init();
    if (this.isMuted || !this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      let timeOffset = 0;
      gain.gain.setValueAtTime(gainStart, now);

      if (freqs.length === 1) {
        osc.frequency.setValueAtTime(freqs[0], now);
        const duration = durations[0] || 0.1;
        gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
        osc.start(now);
        osc.stop(now + duration);
      } else {
        // Play sequence
        osc.start(now);
        freqs.forEach((freq, idx) => {
          const duration = durations[idx] || 0.15;
          if (glide) {
            osc.frequency.exponentialRampToValueAtTime(freq, now + timeOffset + 0.02);
          } else {
            osc.frequency.setValueAtTime(freq, now + timeOffset);
          }
          timeOffset += duration;
        });
        gain.gain.setValueAtTime(gainStart, now + timeOffset - 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, now + timeOffset);
        osc.stop(now + timeOffset);
      }
    } catch (e) {
      console.warn("Audio playTone failed:", e);
    }
  }

  // Play a simple 8-bit style pickup chime (high-pitch happy scale)
  public playPickup() {
    this.playTone([523.25, 659.25, 783.99], [0.08, 0.08, 0.15], "square", 0.08);
  }

  // Play a beautiful hospital delivery chord
  public playDelivery() {
    this.playTone([523.25, 587.33, 659.25, 783.99, 1046.50], [0.06, 0.06, 0.06, 0.06, 0.35], "triangle", 0.12);
  }

  // Play a crunchy crash sound
  public playCrash() {
    this.init();
    if (this.isMuted || !this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const bufferSize = this.ctx.sampleRate * 0.25; // 0.25 seconds of noise
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      
      // Fill with random noise
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noiseNode = this.ctx.createBufferSource();
      noiseNode.buffer = buffer;

      // Bandpass filter to make it sound muffled/metallic like a car collision
      const filter = this.ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(400, now);
      filter.frequency.exponentialRampToValueAtTime(80, now + 0.25);
      filter.Q.setValueAtTime(5, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      noiseNode.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noiseNode.start(now);
      noiseNode.stop(now + 0.25);

      // Add a low-frequency rumble
      this.playTone([110, 55], [0.15, 0.1], "sawtooth", 0.15, true);
    } catch (e) {
      console.warn("Audio playCrash failed:", e);
    }
  }

  // Play a happy win melody
  public playWin() {
    const freqs = [523.25, 659.25, 783.99, 1046.50, 783.99, 1046.50, 1318.51];
    const durs = [0.12, 0.12, 0.12, 0.12, 0.12, 0.12, 0.4];
    this.playTone(freqs, durs, "triangle", 0.12);
  }

  // Play a sad game over melody
  public playGameOver() {
    const freqs = [392.00, 349.23, 311.13, 261.63, 196.00];
    const durs = [0.2, 0.2, 0.2, 0.3, 0.5];
    this.playTone(freqs, durs, "sawtooth", 0.12);
  }

  // Start engine hum
  public startEngine() {
    this.isEngineActive = true;
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Avoid duplication
    if (this.engineOsc) return;

    try {
      const now = this.ctx.currentTime;
      this.engineOsc = this.ctx.createOscillator();
      this.engineGain = this.ctx.createGain();

      this.engineOsc.type = "sawtooth";
      this.engineOsc.frequency.setValueAtTime(65, now); // Deep rumbling idle sound
      
      // Pass through low-pass filter to make it sound like a car cabin
      const lpFilter = this.ctx.createBiquadFilter();
      lpFilter.type = "lowpass";
      lpFilter.frequency.setValueAtTime(220, now);

      this.engineOsc.connect(lpFilter);
      lpFilter.connect(this.engineGain);
      this.engineGain.connect(this.ctx.destination);

      this.engineGain.gain.setValueAtTime(0.015, now); // low baseline rumble volume
      this.engineOsc.start(now);
    } catch (e) {
      console.warn("Audio startEngine failed:", e);
    }
  }

  // Stop engine hum
  public stopEngine() {
    try {
      if (this.engineOsc) {
        this.engineOsc.stop();
        this.engineOsc.disconnect();
        this.engineOsc = null;
      }
      if (this.engineGain) {
        this.engineGain.disconnect();
        this.engineGain = null;
      }
    } catch (e) {
      // ignore
    }
  }

  // Update engine pitch/volume based on speed ratio (0.0 to 1.0)
  public updateEnginePitch(speedRatio: number) {
    if (this.isMuted || !this.ctx || !this.engineOsc || !this.engineGain) return;
    try {
      const now = this.ctx.currentTime;
      // Interpolate frequency from 65Hz (idle) to 180Hz (high speed)
      const targetFreq = 65 + speedRatio * 115;
      this.engineOsc.frequency.setTargetAtTime(targetFreq, now, 0.1);

      // Increase volume slightly at higher revs
      const targetGain = 0.012 + speedRatio * 0.025;
      this.engineGain.gain.setTargetAtTime(targetGain, now, 0.15);
    } catch (e) {
      // ignore
    }
  }

  // Update siren pitch/speed dynamically based on ambulance speed ratio (0.0 to 1.0)
  public updateSirenPitch(speedRatio: number) {
    const ratio = Math.max(0, Math.min(1, speedRatio));

    // 1. If playing the preloaded public-domain audio file, dynamically modulate playbackRate for an realistic speed effect!
    if (this.useAudioFile && this.audioHtmlElement) {
      try {
        // Range playbackRate from 0.88x (idle/slowing) to 1.25x (full speed)
        const targetPlaybackRate = 0.88 + ratio * 0.37;
        this.audioHtmlElement.playbackRate = targetPlaybackRate;
      } catch (e) {
        // ignore
      }
    }

    // 2. Modulate synthesized oscillator/LFO frequencies if using pure Web Audio synthesis fallback
    if (this.sirenOsc1 && this.ctx) {
      try {
        const now = this.ctx.currentTime;
        let targetBaseFreq = 520;
        let targetLfoFreq = 0.3;

        if (this.sirenMode === "wail") {
          targetBaseFreq = 520 + ratio * 100;
          targetLfoFreq = 0.3 + ratio * 0.2;
        } else if (this.sirenMode === "yelp") {
          targetBaseFreq = 580 + ratio * 120;
          targetLfoFreq = 2.4 + ratio * 0.8;
        } else if (this.sirenMode === "phaser") {
          targetBaseFreq = 620 + ratio * 150;
          targetLfoFreq = 8.5 + ratio * 2.5;
        } else if (this.sirenMode === "hilo") {
          targetBaseFreq = 550 + ratio * 90;
          targetLfoFreq = 1.2 + ratio * 0.4;
        }

        this.sirenOsc1.frequency.setTargetAtTime(targetBaseFreq, now, 0.1);
        if (this.sirenLfo) {
          this.sirenLfo.frequency.setTargetAtTime(targetLfoFreq, now, 0.1);
        }
      } catch (e) {
        // ignore
      }
    }
  }

  // Get active siren mode
  public getSirenMode(): "wail" | "yelp" | "phaser" | "hilo" {
    return this.sirenMode;
  }

  // Update siren mode dynamically
  public setSirenMode(mode: "wail" | "yelp" | "phaser" | "hilo") {
    this.sirenMode = mode;
    if (this.isSirenActive && !this.isMuted) {
      this.stopSiren();
      this.startSiren();
    }
  }

  // Toggle/start/stop continuous siren sound with smooth LFO pitch modulations
  public startSiren() {
    this.isSirenActive = true;
    if (this.isMuted) return;

    this.init();

    // 1. If an audio file loaded successfully, play it
    if (this.useAudioFile && this.audioHtmlElement) {
      try {
        this.audioHtmlElement.muted = false;
        this.audioHtmlElement.volume = this.sirenVolume * 0.15;
        const playPromise = this.audioHtmlElement.play();
        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.info("Autoplay block or error playing audio file, using synth:", error);
            this.startSynthSiren();
          });
        }
        return; // Success, audio file started playing
      } catch (e) {
        console.warn("HTMLAudioElement play failed, using synth:", e);
        this.startSynthSiren();
      }
    }

    // 2. Fallback / Default: Pure web-synthesized siren
    this.startSynthSiren();
  }

  private startSynthSiren() {
    if (!this.ctx) return;
    if (this.sirenOsc1) return;

    try {
      const now = this.ctx.currentTime;
      this.sirenOsc1 = this.ctx.createOscillator();
      this.sirenGain = this.ctx.createGain();

      // Audio values tuned based on selected pattern
      let baseFreq = 520;
      let oscType: OscillatorType = "triangle";
      let lfoFreq = 0.3;
      let lfoDepth = 160;
      let lfoType: OscillatorType = "sine";

      if (this.sirenMode === "wail") {
        baseFreq = 520;
        oscType = "triangle";
        lfoFreq = 0.3;     // slow sweep (3.3s)
        lfoDepth = 160;    // sweeps +/- 160Hz (360Hz - 680Hz)
        lfoType = "sine";
      } else if (this.sirenMode === "yelp") {
        baseFreq = 580;
        oscType = "triangle";
        lfoFreq = 2.4;     // rapid wail (2.4 Hz)
        lfoDepth = 180;    // sweeps +/- 180Hz (400Hz - 760Hz)
        lfoType = "sine";
      } else if (this.sirenMode === "phaser") {
        baseFreq = 620;
        oscType = "sawtooth";
        lfoFreq = 8.5;     // extremely rapid computer buzz sweep
        lfoDepth = 240;    // sweeps +/- 240Hz (380Hz - 860Hz)
        lfoType = "sawtooth";
      } else if (this.sirenMode === "hilo") {
        baseFreq = 550;
        oscType = "triangle";
        lfoFreq = 1.2;     // two-tone European pattern
        lfoDepth = 150;    // alternates +/- 150Hz (400Hz and 700Hz)
        lfoType = "square";
      }

      this.sirenOsc1.type = oscType;
      this.sirenOsc1.frequency.setValueAtTime(baseFreq, now);

      // Setup continuous LFO
      this.sirenLfo = this.ctx.createOscillator();
      this.sirenLfoGain = this.ctx.createGain();

      this.sirenLfo.type = lfoType;
      this.sirenLfo.frequency.setValueAtTime(lfoFreq, now);
      this.sirenLfoGain.gain.setValueAtTime(lfoDepth, now);

      // Connect LFO as a pitch modulator
      this.sirenLfo.connect(this.sirenLfoGain);
      this.sirenLfoGain.connect(this.sirenOsc1.frequency);

      // Connect siren to master gain
      this.sirenOsc1.connect(this.sirenGain);
      this.sirenGain.connect(this.ctx.destination);

      // Safe, balanced siren volume scaled by custom volume
      this.sirenGain.gain.setValueAtTime(0.026 * this.sirenVolume * 2, now);

      // Start sound generation
      this.sirenLfo.start(now);
      this.sirenOsc1.start(now);
    } catch (e) {
      console.warn("Audio startSynthSiren failed:", e);
    }
  }

  private stopSynthSiren() {
    try {
      if (this.sirenLfo) {
        this.sirenLfo.stop();
        this.sirenLfo.disconnect();
        this.sirenLfo = null;
      }
      if (this.sirenLfoGain) {
        this.sirenLfoGain.disconnect();
        this.sirenLfoGain = null;
      }
      if (this.sirenOsc1) {
        this.sirenOsc1.stop();
        this.sirenOsc1.disconnect();
        this.sirenOsc1 = null;
      }
      if (this.sirenGain) {
        this.sirenGain.disconnect();
        this.sirenGain = null;
      }
    } catch (e) {
      // ignore
    }
  }

  public stopSiren() {
    // 1. Stop audio file if active
    try {
      if (this.audioHtmlElement) {
        this.audioHtmlElement.pause();
        this.audioHtmlElement.currentTime = 0;
      }
    } catch (e) {
      // ignore
    }

    // 2. Stop synth siren
    this.stopSynthSiren();
  }

  public toggleSiren(active: boolean) {
    if (active) {
      this.startSiren();
    } else {
      this.isSirenActive = false;
      this.stopSiren();
    }
  }
}

export const soundManager = new SoundManager();
