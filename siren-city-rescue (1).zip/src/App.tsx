/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Heart, 
  Clock, 
  Trophy, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  ShieldAlert, 
  ShieldCheck,
  Award,
  BookOpen,
  Info,
  ChevronRight,
  Sparkles,
  Wrench,
  Settings as SettingsIcon,
  Home,
  Star,
  Coins,
  Shield,
  Truck,
  Flame,
  Check,
  User,
  Trash2
} from "lucide-react";
import { GameState } from "./types";
import { GameCanvas } from "./components/GameCanvas";
import { soundManager } from "./utils/sound";
import HospitalBackground2D from "./components/HospitalBackground2D";

interface HighScore {
  name: string;
  score: number;
  rescued: number;
  date: string;
  level: number;
}

interface Upgrades {
  engine: number;   // Max speed upgrade tier (0 to 3)
  steering: number; // Handling steer speed upgrade tier (0 to 3)
  armor: number;    // Chassis lives upgrade tier (0 to 3)
  cabin: number;    // Stretcher capacity upgrade tier (0 to 3)
}

const FLOATING_PARTICLES = [
  { id: 1, x: "12%", y: "85%", delay: "0s", duration: "14s", size: "text-rose-500/25", char: "+" },
  { id: 2, x: "25%", y: "90%", delay: "3s", duration: "18s", size: "text-emerald-500/20", char: "♥" },
  { id: 3, x: "40%", y: "75%", delay: "1.5s", duration: "12s", size: "text-cyan-500/15", char: "+" },
  { id: 4, x: "65%", y: "80%", delay: "5s", duration: "16s", size: "text-rose-500/20", char: "+" },
  { id: 5, x: "78%", y: "95%", delay: "2s", duration: "20s", size: "text-emerald-500/25", char: "♥" },
  { id: 6, x: "88%", y: "70%", delay: "4s", duration: "15s", size: "text-cyan-500/20", char: "+" },
  { id: 7, x: "50%", y: "92%", delay: "6s", duration: "22s", size: "text-white/10", char: "○" },
];

export default function App() {
  // Game state controllers
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [isExited, setIsExited] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"menu" | "garage" | "settings" | "leaderboard">("menu");
  
  // Game stats
  const [score, setScore] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [patientsRescued, setPatientsRescued] = useState<number>(0);
  const [timer, setTimer] = useState<number>(85); // 85 seconds dispatch countdown
  const [carryingCount, setCarryingCount] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [difficulty, setDifficulty] = useState<"easy" | "normal" | "hard">("normal");

  // Premium Persistent attributes (Garage & Currencies)
  const [coins, setCoins] = useState<number>(200); // starts with some pocket coins for first upgrade
  const [xp, setXp] = useState<number>(0);
  const [activeSkin, setActiveSkin] = useState<string>("classic");
  const [unlockedSkins, setUnlockedSkins] = useState<string[]>(["classic"]);
  
  const [upgrades, setUpgrades] = useState<Upgrades>({
    engine: 0,
    steering: 0,
    armor: 0,
    cabin: 0,
  });

  const [playerName, setPlayerName] = useState<string>("Siren Driver");
  const [highScores, setHighScores] = useState<HighScore[]>([]);
  const [showHowTo, setShowHowTo] = useState<boolean>(false);
  const [sirenMode, setSirenMode] = useState<"wail" | "yelp" | "phaser" | "hilo">("wail");

  // Load persistence configurations from localStorage on mount
  useEffect(() => {
    try {
      // 1. High scores
      const storedScores = localStorage.getItem("ambulance_rescue_scores_v2");
      if (storedScores) {
        setHighScores(JSON.parse(storedScores));
      } else {
        const defaults: HighScore[] = [
          { name: "SuperMedic", score: 1850, rescued: 10, date: "2026-07-10", level: 3 },
          { name: "SirenHero", score: 1200, rescued: 8, date: "2026-07-09", level: 2 },
          { name: "FastResponder", score: 650, rescued: 5, date: "2026-07-08", level: 1 },
        ];
        localStorage.setItem("ambulance_rescue_scores_v2", JSON.stringify(defaults));
        setHighScores(defaults);
      }

      // 2. Currencies, Level & XP
      const storedCoins = localStorage.getItem("amb_rescue_coins");
      if (storedCoins) setCoins(parseInt(storedCoins));

      const storedXp = localStorage.getItem("amb_rescue_xp");
      if (storedXp) setXp(parseInt(storedXp));

      const storedLevel = localStorage.getItem("amb_rescue_level");
      if (storedLevel) setCurrentLevel(parseInt(storedLevel));

      // 3. Skins
      const storedActiveSkin = localStorage.getItem("amb_rescue_active_skin");
      if (storedActiveSkin) setActiveSkin(storedActiveSkin);

      const storedUnlockedSkins = localStorage.getItem("amb_rescue_unlocked_skins");
      if (storedUnlockedSkins) setUnlockedSkins(JSON.parse(storedUnlockedSkins));

      // 4. Upgrades Tiers
      const storedUpgrades = localStorage.getItem("amb_rescue_upgrades");
      if (storedUpgrades) setUpgrades(JSON.parse(storedUpgrades));

      // 5. Player Handle Name
      const storedPlayerName = localStorage.getItem("amb_rescue_player_name");
      if (storedPlayerName) setPlayerName(storedPlayerName);

      // 6. Siren Mode
      const storedSirenMode = localStorage.getItem("amb_rescue_siren_mode") as any;
      if (storedSirenMode && ["wail", "yelp", "phaser", "hilo"].includes(storedSirenMode)) {
        setSirenMode(storedSirenMode);
        soundManager.setSirenMode(storedSirenMode);
      }
    } catch (e) {
      console.warn("Could not load stored variables", e);
    }
  }, []);

  const changeSirenMode = (mode: "wail" | "yelp" | "phaser" | "hilo") => {
    setSirenMode(mode);
    soundManager.setSirenMode(mode);
    try {
      localStorage.setItem("amb_rescue_siren_mode", mode);
    } catch (e) {
      // ignore
    }
  };

  // Save Driver Name changes
  const handleNameChange = (val: string) => {
    setPlayerName(val);
    try {
      localStorage.setItem("amb_rescue_player_name", val);
    } catch (e) {
      // ignore
    }
  };

  // Timer interval countdown tick
  useEffect(() => {
    let intervalId: any = null;
    if (gameState === GameState.PLAYING) {
      intervalId = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            clearInterval(intervalId);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [gameState]);

  const handleAddCoins = (amount: number) => {
    setCoins((prev) => {
      const next = prev + amount;
      try {
        localStorage.setItem("amb_rescue_coins", next.toString());
      } catch (e) {
        // ignore
      }
      return next;
    });
  };

  const handleAddXp = (amount: number) => {
    setXp((prev) => {
      const next = prev + amount;
      try {
        localStorage.setItem("amb_rescue_xp", next.toString());
      } catch (e) {
        // ignore
      }
      return next;
    });
  };

  const handleSaveScore = () => {
    const newRecord: HighScore = {
      name: playerName.trim() || "Siren Driver",
      score,
      rescued: patientsRescued,
      date: new Date().toISOString().split("T")[0],
      level: currentLevel,
    };

    const updated = [...highScores, newRecord]
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    setHighScores(updated);
    try {
      localStorage.setItem("ambulance_rescue_scores_v2", JSON.stringify(updated));
    } catch (e) {
      // ignore
    }
  };

  const startGame = () => {
    setScore(0);
    setPatientsRescued(0);
    setCarryingCount(0);
    
    // Starting Timer scales by currentLevel (Level 1: 85s, Level 2: 75s, Level 3: 65s, etc. making it progressively tighter!)
    const levelTime = Math.max(85 - (currentLevel - 1) * 10, 50);
    setTimer(levelTime);

    // Initial lives computed with armor upgrades
    const initialLives = 3 + upgrades.armor;
    setLives(initialLives);

    setGameState(GameState.PLAYING);
    soundManager.setMute(isMuted);
    soundManager.startEngine();
    soundManager.toggleSiren(!isMuted);
  };

  const togglePause = () => {
    if (gameState === GameState.PLAYING) {
      setGameState(GameState.PAUSED);
      soundManager.toggleSiren(false);
      soundManager.stopEngine();
    } else if (gameState === GameState.PAUSED) {
      setGameState(GameState.PLAYING);
      soundManager.toggleSiren(!isMuted);
      soundManager.startEngine();
    }
  };

  const toggleMute = () => {
    const muted = soundManager.toggleMute();
    setIsMuted(muted);
  };

  // Upgrade vehicle item cost computation
  const getUpgradeCost = (category: keyof Upgrades, currentTier: number) => {
    if (currentTier >= 3) return -1; // maxed
    
    // Cost scales by upgrade type & tier
    const baseCosts = {
      engine: [150, 300, 500],
      steering: [150, 300, 500],
      armor: [200, 400, 600],
      cabin: [250, 500, 750],
    };
    return baseCosts[category][currentTier];
  };

  const buyUpgrade = (category: keyof Upgrades) => {
    const currentTier = upgrades[category];
    if (currentTier >= 3) return;

    const cost = getUpgradeCost(category, currentTier);
    if (coins >= cost) {
      const nextCoins = coins - cost;
      setCoins(nextCoins);
      
      const updatedUpgrades = {
        ...upgrades,
        [category]: currentTier + 1,
      };
      setUpgrades(updatedUpgrades);

      try {
        localStorage.setItem("amb_rescue_coins", nextCoins.toString());
        localStorage.setItem("amb_rescue_upgrades", JSON.stringify(updatedUpgrades));
      } catch (e) {
        // ignore
      }

      soundManager.playPickup(); // happy ding chime
    }
  };

  // Ambulance Skins Catalog
  const SKINS_CATALOG = [
    { id: "classic", name: "Red Cross Classic", cost: 0, desc: "Standard City Medical White & Red livery" },
    { id: "cyber", name: "Neon Cyberpunk", cost: 250, desc: "Glossy neon blue plates with cyan underglow" },
    { id: "stealth", name: "Stealth force", cost: 450, desc: "Matte black stealth carbon armor plating" },
    { id: "gold", name: "Golden Rescue Luxe", cost: 750, desc: "Shining gold-gilded premium body paneling" },
  ];

  const selectOrBuySkin = (skinId: string, cost: number) => {
    if (unlockedSkins.includes(skinId)) {
      setActiveSkin(skinId);
      try {
        localStorage.setItem("amb_rescue_active_skin", skinId);
      } catch (e) {
        // ignore
      }
    } else {
      // purchase
      if (coins >= cost) {
        const nextCoins = coins - cost;
        setCoins(nextCoins);
        
        const nextUnlocked = [...unlockedSkins, skinId];
        setUnlockedSkins(nextUnlocked);
        setActiveSkin(skinId);

        try {
          localStorage.setItem("amb_rescue_coins", nextCoins.toString());
          localStorage.setItem("amb_rescue_unlocked_skins", JSON.stringify(nextUnlocked));
          localStorage.setItem("amb_rescue_active_skin", skinId);
        } catch (e) {
          // ignore
        }

        soundManager.playPickup();
      }
    }
  };

  const handleNextLevel = () => {
    // Save previous results
    handleSaveScore();
    
    // Advance Level & save
    const nextLevel = currentLevel + 1;
    setCurrentLevel(nextLevel);
    try {
      localStorage.setItem("amb_rescue_level", nextLevel.toString());
    } catch (e) {
      // ignore
    }

    setGameState(GameState.START);
    setActiveTab("menu");
  };

  const handleResetScores = () => {
    const empty: HighScore[] = [];
    setHighScores(empty);
    try {
      localStorage.setItem("ambulance_rescue_scores_v2", JSON.stringify(empty));
    } catch (e) {
      // ignore
    }
  };

  // Compute game star rating (1 to 3 stars based on timer left)
  const calculateStars = () => {
    if (timer >= 45) return 3;
    if (timer >= 20) return 2;
    return 1;
  };

  const isBrightBackground = isExited || gameState === GameState.START || gameState === GameState.WIN || gameState === GameState.GAME_OVER;

  if (isExited) {
    return (
      <div 
        id="app-root" 
        className="min-h-screen w-full bg-sky-50 text-slate-900 font-sans flex flex-col items-center justify-center p-3 md:p-5 overflow-x-hidden relative"
      >
        {/* Full-screen 2D Hospital Environment Background */}
        <HospitalBackground2D />

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative z-10 w-full max-w-md bg-white/90 border border-cyan-200/80 p-8 rounded-3xl text-center shadow-2xl backdrop-blur-md text-slate-800"
        >
          {/* Flashing Red Beacon */}
          <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto mb-6 text-red-500 animate-pulse">
            <svg className="w-8 h-8 filter drop-shadow-[0_0_4px_rgba(239,68,68,0.8)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
            </svg>
          </div>

          <h2 className="text-2xl font-black font-display text-slate-900 tracking-tight">DISPATCH TERMINATED</h2>
          <p className="text-xs text-rose-600 font-mono uppercase tracking-widest font-black mt-1">Shift Logged Out Successfully</p>

          <p className="text-slate-600 text-xs my-6 leading-relaxed font-mono bg-slate-50 border border-slate-100 p-4 rounded-xl">
            Secure connection to Metropolitan Medical Mainframe has been closed. Driver unit telemetry saved. Thank you for your service.
          </p>

          <button
            onClick={() => setIsExited(false)}
            className="w-full py-3.5 bg-gradient-to-r from-cyan-600 to-blue-500 hover:from-cyan-500 hover:to-blue-400 text-white font-bold rounded-xl cursor-pointer shadow-lg shadow-cyan-600/20 transition-all text-sm uppercase tracking-wider font-display border-t border-cyan-400/20"
          >
            Reconnect Drive Unit
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div 
      id="app-root" 
      className={`min-h-screen w-full font-sans flex flex-col items-center justify-between p-3 md:p-5 overflow-x-hidden relative transition-colors duration-500 ${
        isBrightBackground ? "bg-sky-50 text-slate-900" : "bg-slate-950 text-slate-100"
      }`}
    >
      {/* Immersive Full-screen 2D Hospital Environment Background for Start, Win, and Game Over Screen */}
      {isBrightBackground && <HospitalBackground2D />}

      {/* 1. FLUID HEADER BAR WITH CONTINUOUS COINS STAT */}
      <header 
        id="app-header" 
        className="relative z-10 w-full max-w-5xl bg-slate-900/80 border border-slate-800/80 rounded-2xl px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl mb-4 backdrop-blur-md"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-red-500 flex items-center justify-center shadow-lg shadow-rose-500/20">
            <span className="text-white font-extrabold text-xl font-mono tracking-tighter leading-none">+</span>
          </div>
          <div>
            <h1 className="text-lg md:text-xl font-bold tracking-tight bg-gradient-to-r from-red-400 via-rose-300 to-white bg-clip-text text-transparent font-display">
              SIREN RESCUE
            </h1>
            <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">Emergency Response Dispatch</p>
          </div>
        </div>

        {/* Player Profile stats & Coins */}
        <div className="flex items-center gap-4 flex-wrap justify-center">
          
          {/* Driver units */}
          <div className="flex items-center gap-2 bg-slate-950/60 border border-slate-800/80 px-3 py-1.5 rounded-xl font-mono text-xs">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-300 font-bold max-w-[100px] truncate">{playerName}</span>
            <span className="text-rose-500 text-[10px] font-bold">LV.{currentLevel}</span>
          </div>

          {/* Persistent Coin stash */}
          <div className="flex items-center gap-2 bg-slate-950/60 border border-slate-800/80 px-3 py-1.5 rounded-xl font-mono text-xs shadow-inner">
            <Coins className="w-4 h-4 text-yellow-400 animate-bounce" />
            <span className="text-slate-400 text-[10px]">Stash:</span>
            <span className="text-yellow-400 font-black tracking-tight">{coins} COINS</span>
          </div>

          <div className="h-6 w-[1px] bg-slate-800 hidden sm:block" />

          {/* Quick Sound settings & Manual Info */}
          <div className="flex items-center gap-2">
            <button
              id="mute-quick-toggle"
              onClick={toggleMute}
              className={`p-2 rounded-lg border transition-all cursor-pointer ${
                isMuted 
                  ? "bg-slate-950 border-rose-500/30 text-rose-400" 
                  : "bg-slate-950 border-slate-800 text-slate-300 hover:text-white"
              }`}
              title={isMuted ? "Unmute sounds" : "Mute sounds"}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              id="info-quick-toggle"
              onClick={() => setShowHowTo(true)}
              className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-white cursor-pointer transition-all"
              title="Driving Manual"
            >
              <BookOpen className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      {/* 2. MAIN WORKSPACE / GAMEPORT / OVERLAYS */}
      <main id="game-stage" className="relative w-full max-w-5xl flex-grow flex flex-col items-center justify-center min-h-[480px]">
        
        {/* PLAYING HUB SCREEN */}
        {gameState === GameState.PLAYING || gameState === GameState.PAUSED ? (
          <div id="active-play-screen" className="w-full flex flex-col gap-4">
            
            {/* Live Playing HUD display */}
            <div id="live-hud" className="w-full bg-slate-900/85 backdrop-blur-md border border-slate-800/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
              
              {/* Score & Lives stats */}
              <div className="flex items-center gap-5 w-full sm:w-auto justify-around">
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">Dispatched score</span>
                  <span className="text-xl font-black font-mono text-emerald-400 tracking-tight">
                    {score.toString().padStart(5, "0")}
                  </span>
                </div>

                <div className="h-8 w-[1px] bg-slate-800" />

                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Ambulance Health</span>
                  <div className="flex gap-1.5">
                    {[...Array(3 + upgrades.armor)].map((_, i) => (
                      <Heart
                        id={`hud-heart-${i}`}
                        key={i}
                        className={`w-5 h-5 transition-all duration-300 ${
                          i < lives 
                            ? "text-rose-500 fill-rose-500 scale-100 animate-pulse" 
                            : "text-slate-700 fill-slate-900 scale-90"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Progress and Cabin stats */}
              <div className="flex items-center gap-5 w-full sm:w-auto justify-around">
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">Level Progress</span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-black text-rose-400 font-mono">
                      {patientsRescued} <span className="text-xs text-slate-500">/ 10</span>
                    </span>
                    <div className="w-14 h-2 bg-slate-950 rounded-full overflow-hidden hidden md:block">
                      <div 
                        className="h-full bg-gradient-to-r from-red-500 to-rose-400 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min((patientsRescued / 10) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="h-8 w-[1px] bg-slate-800" />

                {/* Stretcher Cabin Slots */}
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Stretcher Cabin</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-mono font-bold text-slate-300">
                      [{carryingCount}/{3 + upgrades.cabin}]
                    </span>
                    <div className="flex gap-1">
                      {[...Array(3 + upgrades.cabin)].map((_, i) => (
                        <div
                          key={i}
                          className={`w-3.5 h-4.5 rounded transition-all duration-300 border ${
                            i < carryingCount
                              ? "bg-rose-500 border-rose-400 animate-pulse"
                              : "bg-slate-950 border-slate-850"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Emergency Clock and Pause */}
              <div className="flex items-center gap-5 w-full sm:w-auto justify-around">
                <div className="flex flex-col items-end">
                  <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">Emergency Clock</span>
                  <div className="flex items-center gap-1.5">
                    <Clock className={`w-4 h-4 ${timer < 15 ? "text-red-500 animate-ping" : "text-cyan-400"}`} />
                    <span className={`text-xl font-black font-mono tracking-tight ${
                      timer < 15 ? "text-red-500 animate-pulse" : "text-cyan-400"
                    }`}>
                      {timer}s
                    </span>
                  </div>
                </div>

                <div className="h-8 w-[1px] bg-slate-800" />

                <button
                  id="pause-toggle-button"
                  onClick={togglePause}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  {gameState === GameState.PAUSED ? (
                    <>
                      <Play className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
                      <span>Resume</span>
                    </>
                  ) : (
                    <>
                      <Pause className="w-3.5 h-3.5 text-rose-400" />
                      <span>Pause</span>
                    </>
                  )}
                </button>
              </div>

            </div>

            {/* Game Canvas Wrapper */}
            <div id="wrapper-box" className="w-full aspect-[4/3] max-h-[600px] relative">
              <GameCanvas
                gameState={gameState}
                score={score}
                lives={lives}
                patientsRescued={patientsRescued}
                timer={timer}
                isMuted={isMuted}
                onScoreChange={setScore}
                onLivesChange={setLives}
                onPatientsRescued={setPatientsRescued}
                onTimerChange={setTimer}
                onGameStateChange={setGameState}
                onPatientCountChange={setCarryingCount}
                activeSkin={activeSkin}
                upgrades={upgrades}
                difficulty={difficulty}
                onAddCoins={handleAddCoins}
                onAddXp={handleAddXp}
                currentLevel={currentLevel}
                sirenMode={sirenMode}
                onSirenModeChange={changeSirenMode}
              />

              {/* Pause menu overlay */}
              {gameState === GameState.PAUSED && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm rounded-2xl flex items-center justify-center p-6 z-20">
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-sm w-full text-center shadow-2xl flex flex-col gap-5"
                  >
                    <div className="w-14 h-14 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center mx-auto text-rose-400 animate-pulse">
                      <Pause className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold tracking-tight">Mission Suspended</h3>
                      <p className="text-xs text-slate-500 font-mono mt-0.5">THE PATIENTS ARE WAITING</p>
                    </div>

                    <div className="flex flex-col gap-2.5">
                      <button
                        id="pause-resume"
                        onClick={togglePause}
                        className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-500 hover:from-red-500 hover:to-rose-400 text-white font-bold rounded-xl cursor-pointer shadow-lg shadow-rose-600/15 transition-all text-sm uppercase tracking-wide"
                      >
                        Resume Driver Shift
                      </button>
                      <button
                        id="pause-quit"
                        onClick={() => {
                          setGameState(GameState.START);
                          soundManager.stopSiren();
                          soundManager.stopEngine();
                        }}
                        className="w-full py-2.5 bg-slate-950 hover:bg-slate-850 text-slate-300 text-xs font-semibold rounded-xl cursor-pointer border border-slate-800 transition-all"
                      >
                        Quit Dispatch
                      </button>
                    </div>
                  </motion.div>
                </div>
              )}

            </div>
          </div>
        ) : null}

        {/* START MENU MAIN HUD CONTAINER */}
        <AnimatePresence>
          {gameState === GameState.START && (
            <motion.div
              id="start-menu-tab-layout"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="w-full grid grid-cols-1 md:grid-cols-12 gap-5 p-1"
            >
              
              {/* Left Column Controls / Navigation Tabs */}
              <div className="md:col-span-3 flex flex-col gap-3">
                <button
                  id="tab-menu"
                  onClick={() => setActiveTab("menu")}
                  className={`w-full py-3 px-4 rounded-xl border text-left font-bold transition-all text-sm flex items-center gap-3 cursor-pointer ${
                    activeTab === "menu" 
                      ? "bg-gradient-to-r from-red-950/40 to-slate-900 border-red-500/50 text-red-400 shadow-md shadow-red-500/5" 
                      : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <Home className="w-4 h-4 text-cyan-400" />
                  <span>🏥 COMMAND CENTRE</span>
                </button>

                <button
                  id="tab-garage"
                  onClick={() => setActiveTab("garage")}
                  className={`w-full py-3 px-4 rounded-xl border text-left font-bold transition-all text-sm flex items-center gap-3 cursor-pointer ${
                    activeTab === "garage" 
                      ? "bg-gradient-to-r from-red-950/40 to-slate-900 border-red-500/50 text-red-400 shadow-md shadow-red-500/5" 
                      : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <Wrench className="w-4 h-4 text-rose-400" />
                  <span>🔧 UPGRADE BAY</span>
                </button>

                <button
                  id="tab-leaderboard"
                  onClick={() => setActiveTab("leaderboard")}
                  className={`w-full py-3 px-4 rounded-xl border text-left font-bold transition-all text-sm flex items-center gap-3 cursor-pointer ${
                    activeTab === "leaderboard" 
                      ? "bg-gradient-to-r from-red-950/40 to-slate-900 border-red-500/50 text-red-400 shadow-md shadow-red-500/5" 
                      : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <Trophy className="w-4 h-4 text-yellow-500" />
                  <span>📊 DISPATCH RECORDS</span>
                </button>

                <button
                  id="tab-settings"
                  onClick={() => setActiveTab("settings")}
                  className={`w-full py-3 px-4 rounded-xl border text-left font-bold transition-all text-sm flex items-center gap-3 cursor-pointer ${
                    activeTab === "settings" 
                      ? "bg-gradient-to-r from-red-950/40 to-slate-900 border-red-500/50 text-red-400 shadow-md shadow-red-500/5" 
                      : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <SettingsIcon className="w-4 h-4 text-slate-400" />
                  <span>⚙️ SYSTEM SETTINGS</span>
                </button>

                {/* Training Guide Quick Box */}
                <div className="bg-slate-900/40 border border-slate-800/60 p-4 rounded-2xl hidden md:block">
                  <div className="flex items-center gap-2 mb-2 text-slate-300">
                    <Info className="w-3.5 h-3.5 text-rose-500" />
                    <span className="text-xs font-bold font-mono">QUICK INSTRUCTION</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-mono">
                    Accelerate: <span className="text-yellow-500 font-bold">W</span><br />
                    Steer: <span className="text-yellow-500 font-bold">A / D</span><br />
                    Reverse/Brake: <span className="text-yellow-500 font-bold">S</span><br />
                    Steering behaves realistically—you only turn while rolling!
                  </p>
                </div>

                {/* PREMIUM EMERGENCY ER BAY STATUS MONITOR (hidden on command centre tab to prevent duplication) */}
                {activeTab !== "menu" && (
                  <div className="bg-slate-900/60 border border-slate-800/80 p-4 rounded-2xl flex flex-col gap-3 shadow-lg relative overflow-hidden backdrop-blur-md hidden md:flex">
                    {/* Flashing medical grid lines decoration */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(244,63,94,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(244,63,94,0.02)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />

                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 relative z-10">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                        <span className="text-[10px] font-black font-mono tracking-wider text-rose-400 uppercase">ER DEPT MONITOR</span>
                      </div>
                      <span className="text-[9px] font-mono text-slate-500 font-bold">STATION: METRO-GEN</span>
                    </div>

                    {/* Medical personnel roster */}
                    <div className="space-y-1.5 relative z-10">
                      <span className="text-[9px] font-mono font-bold text-slate-400 uppercase block tracking-wider">Active Trauma Roster</span>
                      
                      <div className="flex flex-col gap-1 text-[10px] font-mono">
                        <div className="flex justify-between items-center bg-slate-950/40 px-2 py-1.5 rounded border border-slate-850">
                          <span className="text-slate-300 font-bold">🩺 Dr. Elizabeth Vance</span>
                          <span className="text-rose-400 font-bold bg-rose-400/10 px-1 py-0.5 rounded text-[8px] uppercase">ER Lead</span>
                        </div>
                        <div className="flex justify-between items-center bg-slate-950/40 px-2 py-1.5 rounded border border-slate-850">
                          <span className="text-slate-300 font-bold">🏥 Nurse Sarah Lin</span>
                          <span className="text-emerald-400 font-bold bg-emerald-400/10 px-1 py-0.5 rounded text-[8px] uppercase">Trauma</span>
                        </div>
                        <div className="flex justify-between items-center bg-slate-950/40 px-2 py-1.5 rounded border border-slate-850">
                          <span className="text-slate-300 font-bold">🚑 Paramedic Marcus Roy</span>
                          <span className="text-cyan-400 font-bold bg-cyan-400/10 px-1 py-0.5 rounded text-[8px] uppercase">Rescue</span>
                        </div>
                      </div>
                    </div>

                    {/* Medical Equipment checklist */}
                    <div className="space-y-1.5 relative z-10">
                      <span className="text-[9px] font-mono font-bold text-slate-400 uppercase block tracking-wider">Bay Deployment Inventory</span>
                      <div className="grid grid-cols-2 gap-1.5 text-[9px] font-mono">
                        <div className="bg-slate-950/50 p-1.5 rounded border border-slate-850 flex flex-col gap-0.5">
                          <span className="text-slate-500 font-bold">Stretchers</span>
                          <span className="text-slate-200 font-extrabold text-[10px]">4 / 4 LOADED</span>
                        </div>
                        <div className="bg-slate-950/50 p-1.5 rounded border border-slate-850 flex flex-col gap-0.5">
                          <span className="text-slate-500 font-bold">Defibrillators</span>
                          <span className="text-emerald-400 font-extrabold text-[10px]">2 / 2 READY</span>
                        </div>
                      </div>
                    </div>

                    {/* Visual flashing alarm bar status */}
                    <div className="flex gap-1.5 pt-1.5 border-t border-slate-800/60 relative z-10">
                      <div className="h-1 flex-1 bg-rose-600 animate-pulse rounded-full" />
                      <div className="h-1 flex-grow-[2] bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 w-3/4 rounded-full" />
                      </div>
                      <div className="h-1 flex-1 bg-blue-600 animate-pulse rounded-full" style={{ animationDelay: "0.2s" }} />
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column Content Panel depending on activeTab */}
              <div className="md:col-span-9">
                <AnimatePresence mode="wait">
                  
                  {/* TAB 1: PLAY MENU (HERO PANEL) */}
                  {activeTab === "menu" && (
                    <motion.div
                      key="tab-menu-content"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6"
                    >
                      {/* LEFT COLUMN: THE DISPATCH DESK */}
                      <div className="lg:col-span-6 bg-slate-900/70 border border-slate-800/80 rounded-3xl p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden backdrop-blur-md min-h-[420px]">
                        {/* Flashing top alarm bar decoration */}
                        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-rose-500 to-blue-600 animate-pulse" />

                        <div className="flex flex-col gap-5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 flex items-center justify-center bg-red-600/15 border border-red-500/40 rounded-xl shrink-0 animate-pulse">
                              <svg className="w-5 h-5 text-red-500 fill-red-500 filter drop-shadow-[0_0_3px_rgba(239,68,68,0.8)]" viewBox="0 0 24 24">
                                <path d="M19 10.5h-5.5V5c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v5.5H5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5h5.5V19c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5v-5.5H19c.83 0 1.5-.67 1.5-1.5s-.67-1.5-1.5-1.5z" />
                              </svg>
                            </div>
                            <div className="flex flex-col">
                              <h2 className="text-2xl md:text-3xl font-black tracking-tight text-white leading-none font-display uppercase">
                                Ambulance Rescue
                              </h2>
                              <span className="text-[9px] font-mono font-black text-rose-500 uppercase tracking-widest mt-0.5">Critical Care Deployment Hub</span>
                            </div>
                          </div>
                          
                          <p className="text-slate-300 text-xs leading-relaxed font-mono">
                            Metropolis is in critical gridlock! Guide your customized medical unit through traffic AI, avoid hazardous barriers, rescue injured citizens, and secure them safely in the emergency hospital bays before time expires.
                          </p>

                          {/* THE THREE REQUESTED LARGE BUTTONS */}
                          <div className="flex flex-col gap-3 mt-1">
                            {/* 1. START MISSION BUTTON */}
                            <button
                              id="start-mission-large-action"
                              onClick={startGame}
                              className="w-full py-4 bg-gradient-to-r from-emerald-600 to-cyan-500 hover:from-emerald-500 hover:to-cyan-400 text-white font-extrabold text-md rounded-xl flex items-center justify-center gap-3 cursor-pointer shadow-lg shadow-emerald-600/20 transform active:scale-[0.99] transition-all font-display uppercase tracking-wider border border-emerald-500/30"
                            >
                              <Play className="w-5 h-5 fill-white text-white" />
                              <span>START MISSION</span>
                            </button>

                            {/* 2. HOW TO PLAY BUTTON */}
                            <button
                              id="how-to-play-large-action"
                              onClick={() => setShowHowTo(true)}
                              className="w-full py-3.5 bg-slate-950 hover:bg-slate-850 text-slate-100 border border-slate-800 text-sm font-bold rounded-xl cursor-pointer transition-all uppercase tracking-wider flex items-center justify-center gap-2.5 hover:border-cyan-500/30 hover:shadow-[0_0_12px_rgba(6,182,212,0.1)]"
                            >
                              <BookOpen className="w-4 h-4 text-cyan-400" />
                              <span>HOW TO PLAY</span>
                            </button>

                            {/* 3. EXIT BUTTON */}
                            <button
                              id="exit-large-action"
                              onClick={() => setIsExited(true)}
                              className="w-full py-3.5 bg-slate-950/40 hover:bg-red-950/20 text-slate-400 hover:text-red-400 border border-slate-850 hover:border-red-500/20 text-sm font-bold rounded-xl cursor-pointer transition-all uppercase tracking-wider flex items-center justify-center gap-2.5"
                            >
                              <Home className="w-4 h-4 text-rose-500" />
                              <span>EXIT DISPATCH</span>
                            </button>
                          </div>
                        </div>

                        {/* Driver metadata subpanel */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-800/60">
                          {/* Driver name input */}
                          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/60 space-y-1">
                            <label className="block text-[8px] font-mono font-bold text-slate-400 uppercase tracking-widest">
                              Driver Unit Handle
                            </label>
                            <input
                              id="driver-input"
                              type="text"
                              maxLength={12}
                              value={playerName}
                              onChange={(e) => handleNameChange(e.target.value)}
                              placeholder="Driver handle..."
                              className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-white focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all font-mono"
                            />
                          </div>

                          {/* Current levels stats */}
                          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/60 flex items-center justify-between">
                            <div className="space-y-0.5">
                              <span className="block text-[8px] font-mono font-bold text-slate-400 uppercase tracking-widest">
                                CURRENT MISSION
                              </span>
                              <span className="text-sm font-black text-rose-400 font-mono">LEVEL {currentLevel}</span>
                            </div>
                            <div className="h-6 w-[1px] bg-slate-800" />
                            <div className="text-right">
                              <span className="block text-[8px] font-mono font-bold text-slate-400 uppercase tracking-widest">
                                TOTAL STASH
                              </span>
                              <span className="text-xs font-bold text-slate-200 font-mono">{coins} COINS</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* RIGHT COLUMN: DETAILED HOSPITAL ENTRANCE / ER ADMISSIONS MONITOR */}
                      <div className="lg:col-span-6 bg-slate-900/70 border border-cyan-500/20 shadow-lg shadow-cyan-500/5 rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden backdrop-blur-md min-h-[420px]">
                        {/* Medical grid blueprint background decoration */}
                        <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.01)_1px,transparent_1px)] bg-[size:14px_14px] pointer-events-none" />
                        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-400" />

                        <div className="flex flex-col gap-4 relative z-10">
                          {/* Board Header with Pulsing Red Cross Logo */}
                          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                            <div className="flex items-center gap-2">
                              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse relative">
                                <span className="absolute inset-0 rounded-full bg-cyan-400 animate-ping opacity-75" />
                              </span>
                              <span className="text-xs font-black font-mono tracking-widest text-cyan-400 uppercase">ER BAY ADMISSIONS BOARD</span>
                            </div>
                            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-red-500/10 border border-red-500/20 rounded-md text-red-400 text-[8px] font-bold font-mono">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                              <span>CROSS ACTIVE</span>
                            </div>
                          </div>

                          {/* AMBULANCE PARKING AREA */}
                          <div className="bg-slate-950/80 border border-dashed border-yellow-500/30 p-3 rounded-2xl space-y-1.5 relative overflow-hidden">
                            {/* Yellow parking hash marks decoration */}
                            <div className="absolute top-0 right-0 w-8 h-8 bg-[repeating-linear-gradient(-45deg,rgba(234,179,8,0.06),rgba(234,179,8,0.06)_4px,transparent_4px,transparent_8px)]" />
                            
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-mono font-bold text-yellow-500 uppercase tracking-widest">AMBULANCE PARKING BAY 01</span>
                              <span className="text-[9px] font-mono font-bold bg-yellow-500/15 px-1.5 py-0.5 rounded text-yellow-500 border border-yellow-500/20 uppercase">STANDBY SECURE</span>
                            </div>
                            
                            {/* Ambulance status logs */}
                            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[10px] font-mono">
                              <div className="flex flex-col">
                                <span className="text-slate-500 font-bold text-[9px] uppercase">Chassis Armor</span>
                                <span className="text-slate-300 font-bold">Shield Tier {upgrades.armor}/3</span>
                              </div>
                              <div className="flex flex-col">
                                <span className="text-slate-500 font-bold text-[9px] uppercase">Engine Performance</span>
                                <span className="text-slate-300 font-bold">Max Speed Tier {upgrades.engine}/3</span>
                              </div>
                              <div className="flex flex-col">
                                <span className="text-slate-500 font-bold text-[9px] uppercase">Equipped Livery</span>
                                <span className="text-cyan-400 font-extrabold capitalize">{activeSkin} livery</span>
                              </div>
                              <div className="flex flex-col">
                                <span className="text-slate-500 font-bold text-[9px] uppercase">Cabin Capacity</span>
                                <span className="text-slate-300 font-bold">{3 + upgrades.cabin} stretchers</span>
                              </div>
                            </div>
                          </div>

                          {/* DOCTORS, NURSES, PARAMEDICS, PATIENTS ROSTER */}
                          <div className="space-y-1.5 max-h-[175px] overflow-y-auto pr-1">
                            {/* Dr. Elizabeth Vance */}
                            <div className="flex items-center justify-between bg-slate-950/40 border border-slate-850 px-2.5 py-1.5 rounded-xl">
                              <div className="flex items-center gap-2">
                                <span className="text-sm">🩺</span>
                                <div className="flex flex-col">
                                  <span className="text-[10px] font-bold text-slate-200">Dr. Elizabeth Vance</span>
                                  <span className="text-[8px] text-slate-400 font-mono">Trauma Surgeon & ER Chief</span>
                                </div>
                              </div>
                              <span className="text-[8px] font-bold font-mono bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded uppercase border border-emerald-500/20">PREPPING ER 3</span>
                            </div>

                            {/* Nurse Sarah Lin */}
                            <div className="flex items-center justify-between bg-slate-950/40 border border-slate-850 px-2.5 py-1.5 rounded-xl">
                              <div className="flex items-center gap-2">
                                <span className="text-sm">🏥</span>
                                <div className="flex flex-col">
                                  <span className="text-[10px] font-bold text-slate-200">Nurse Sarah Lin</span>
                                  <span className="text-[8px] text-slate-400 font-mono">Head Triage Nurse</span>
                                </div>
                              </div>
                              <span className="text-[8px] font-bold font-mono bg-cyan-500/10 text-cyan-400 px-1.5 py-0.5 rounded uppercase border border-cyan-500/20">TRIAGE ACTIVE</span>
                            </div>

                            {/* Paramedic Marcus Roy */}
                            <div className="flex items-center justify-between bg-slate-950/40 border border-slate-850 px-2.5 py-1.5 rounded-xl">
                              <div className="flex items-center gap-2">
                                <span className="text-sm">🚑</span>
                                <div className="flex flex-col">
                                  <span className="text-[10px] font-bold text-slate-200">Paramedic Marcus Roy</span>
                                  <span className="text-[8px] text-slate-400 font-mono">Senior Rescue Dispatcher</span>
                                </div>
                              </div>
                              <span className="text-[8px] font-bold font-mono bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded uppercase border border-indigo-500/20">SIRENS ARMED</span>
                            </div>

                            {/* Patient Liam Mercer */}
                            <div className="flex items-center justify-between bg-slate-950/40 border border-slate-850 px-2.5 py-1.5 rounded-xl">
                              <div className="flex items-center gap-2">
                                <span className="text-sm">🧑‍🦽</span>
                                <div className="flex flex-col">
                                  <span className="text-[10px] font-bold text-slate-200">Patient Liam (Wheelchair)</span>
                                  <span className="text-[8px] text-slate-400 font-mono">Fractured Femur, Stable</span>
                                </div>
                              </div>
                              <span className="text-[8px] font-bold font-mono bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded uppercase border border-blue-500/20">STABLE</span>
                            </div>

                            {/* Patient Sofia Alvarez */}
                            <div className="flex items-center justify-between bg-slate-950/40 border border-slate-850 px-2.5 py-1.5 rounded-xl">
                              <div className="flex items-center gap-2">
                                <span className="text-sm">🛌</span>
                                <div className="flex flex-col">
                                  <span className="text-[10px] font-bold text-slate-200">Patient Sofia (Stretcher)</span>
                                  <span className="text-[8px] text-slate-400 font-mono">Critical Respiratory Support</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <span className="text-[8px] font-bold font-mono bg-rose-500/10 text-rose-400 px-1.5 py-0.5 rounded border border-rose-500/20">CRITICAL</span>
                                <span className="text-[9px] font-mono text-rose-500 font-black animate-pulse">88 bpm</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* BEACON LIGHT PULSATIONS BAR */}
                        <div className="flex items-center gap-2 pt-3 border-t border-slate-800 relative z-10">
                          <div className="h-1.5 flex-1 rounded bg-red-600 animate-pulse" style={{ animationDuration: "0.5s" }} />
                          <span className="text-[8px] font-mono font-extrabold text-slate-500 uppercase tracking-widest shrink-0">BEACON LIGHT FIELD</span>
                          <div className="h-1.5 flex-1 rounded bg-blue-600 animate-pulse" style={{ animationDuration: "0.7s" }} />
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* TAB 2: GARAGE VEHICLE UPGRADES & SKINS */}
                  {activeTab === "garage" && (
                    <motion.div
                      key="tab-garage-content"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="bg-slate-900/60 border border-slate-800/80 rounded-3xl p-6 shadow-2xl backdrop-blur-md min-h-[400px] flex flex-col gap-6"
                    >
                      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-2.5">
                          <Wrench className="w-5 h-5 text-rose-500" />
                          <h3 className="text-xl font-bold font-display text-white">UPGRADE GARAGE & PAINT</h3>
                        </div>
                        <span className="text-xs font-mono bg-yellow-400/10 border border-yellow-400/20 px-3 py-1 rounded-full text-yellow-400 font-bold">
                          AVAILABLE COINS: {coins}
                        </span>
                      </div>

                      {/* Upgrade Items Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        
                        {/* 1. ENGINE SPEED */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 flex flex-col justify-between gap-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <Flame className="w-4 h-4 text-orange-500" />
                                <h4 className="text-sm font-bold text-slate-200">Engine V8 (Max Speed)</h4>
                              </div>
                              <p className="text-[11px] text-slate-400 font-mono">Increases top velocity of the ambulance on roads.</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-rose-400">TIER {upgrades.engine}/3</span>
                          </div>

                          <div className="flex gap-1.5 my-1">
                            {[1, 2, 3].map((t) => (
                              <div 
                                key={t} 
                                className={`h-1.5 flex-grow rounded-full ${
                                  t <= upgrades.engine ? "bg-gradient-to-r from-red-500 to-orange-400" : "bg-slate-800"
                                }`} 
                              />
                            ))}
                          </div>

                          {upgrades.engine < 3 ? (
                            <button
                              id="buy-engine-upgrade"
                              onClick={() => buyUpgrade("engine")}
                              disabled={coins < getUpgradeCost("engine", upgrades.engine)}
                              className={`w-full py-2 rounded-lg text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 ${
                                coins >= getUpgradeCost("engine", upgrades.engine)
                                  ? "bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black cursor-pointer"
                                  : "bg-slate-800 text-slate-500 cursor-not-allowed"
                              }`}
                            >
                              <span>UPGRADE ENGINE</span>
                              <span>•</span>
                              <span className="flex items-center gap-0.5 font-bold">
                                <Coins className="w-3.5 h-3.5" />
                                {getUpgradeCost("engine", upgrades.engine)}
                              </span>
                            </button>
                          ) : (
                            <div className="w-full py-2 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-bold text-center rounded-lg flex items-center justify-center gap-1">
                              <Check className="w-3.5 h-3.5" /> MAX UPGRADE
                            </div>
                          )}
                        </div>

                        {/* 2. STEERING HANDLING */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 flex flex-col justify-between gap-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <Truck className="w-4 h-4 text-cyan-400" />
                                <h4 className="text-sm font-bold text-slate-200">Steer Grip (Handling)</h4>
                              </div>
                              <p className="text-[11px] text-slate-400 font-mono">Improves turning radius and agility at high speeds.</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-rose-400">TIER {upgrades.steering}/3</span>
                          </div>

                          <div className="flex gap-1.5 my-1">
                            {[1, 2, 3].map((t) => (
                              <div 
                                key={t} 
                                className={`h-1.5 flex-grow rounded-full ${
                                  t <= upgrades.steering ? "bg-gradient-to-r from-cyan-500 to-blue-400" : "bg-slate-800"
                                }`} 
                              />
                            ))}
                          </div>

                          {upgrades.steering < 3 ? (
                            <button
                              id="buy-steering-upgrade"
                              onClick={() => buyUpgrade("steering")}
                              disabled={coins < getUpgradeCost("steering", upgrades.steering)}
                              className={`w-full py-2 rounded-lg text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 ${
                                coins >= getUpgradeCost("steering", upgrades.steering)
                                  ? "bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black cursor-pointer"
                                  : "bg-slate-800 text-slate-500 cursor-not-allowed"
                              }`}
                            >
                              <span>UPGRADE STEERING</span>
                              <span>•</span>
                              <span className="flex items-center gap-0.5 font-bold">
                                <Coins className="w-3.5 h-3.5" />
                                {getUpgradeCost("steering", upgrades.steering)}
                              </span>
                            </button>
                          ) : (
                            <div className="w-full py-2 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-bold text-center rounded-lg flex items-center justify-center gap-1">
                              <Check className="w-3.5 h-3.5" /> MAX UPGRADE
                            </div>
                          )}
                        </div>

                        {/* 3. ARMOR CHASSIS (LIVES) */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 flex flex-col justify-between gap-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <Shield className="w-4 h-4 text-emerald-400" />
                                <h4 className="text-sm font-bold text-slate-200">Chassis Armor (Health)</h4>
                              </div>
                              <p className="text-[11px] text-slate-400 font-mono">Reinforces ambulance body to grant extra crash lives.</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-rose-400">TIER {upgrades.armor}/3</span>
                          </div>

                          <div className="flex gap-1.5 my-1">
                            {[1, 2, 3].map((t) => (
                              <div 
                                key={t} 
                                className={`h-1.5 flex-grow rounded-full ${
                                  t <= upgrades.armor ? "bg-gradient-to-r from-emerald-500 to-teal-400" : "bg-slate-800"
                                }`} 
                              />
                            ))}
                          </div>

                          {upgrades.armor < 3 ? (
                            <button
                              id="buy-armor-upgrade"
                              onClick={() => buyUpgrade("armor")}
                              disabled={coins < getUpgradeCost("armor", upgrades.armor)}
                              className={`w-full py-2 rounded-lg text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 ${
                                coins >= getUpgradeCost("armor", upgrades.armor)
                                  ? "bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black cursor-pointer"
                                  : "bg-slate-800 text-slate-500 cursor-not-allowed"
                              }`}
                            >
                              <span>UPGRADE ARMOR</span>
                              <span>•</span>
                              <span className="flex items-center gap-0.5 font-bold">
                                <Coins className="w-3.5 h-3.5" />
                                {getUpgradeCost("armor", upgrades.armor)}
                              </span>
                            </button>
                          ) : (
                            <div className="w-full py-2 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-bold text-center rounded-lg flex items-center justify-center gap-1">
                              <Check className="w-3.5 h-3.5" /> MAX UPGRADE
                            </div>
                          )}
                        </div>

                        {/* 4. CABIN CAPACITY */}
                        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 flex flex-col justify-between gap-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <Heart className="w-4 h-4 text-rose-400" />
                                <h4 className="text-sm font-bold text-slate-200">Stretcher Cabin Slots</h4>
                              </div>
                              <p className="text-[11px] text-slate-400 font-mono">Enlarges back cabin to load up extra patients at once.</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-rose-400">TIER {upgrades.cabin}/3</span>
                          </div>

                          <div className="flex gap-1.5 my-1">
                            {[1, 2, 3].map((t) => (
                              <div 
                                key={t} 
                                className={`h-1.5 flex-grow rounded-full ${
                                  t <= upgrades.cabin ? "bg-gradient-to-r from-rose-500 to-pink-400" : "bg-slate-800"
                                }`} 
                              />
                            ))}
                          </div>

                          {upgrades.cabin < 3 ? (
                            <button
                              id="buy-cabin-upgrade"
                              onClick={() => buyUpgrade("cabin")}
                              disabled={coins < getUpgradeCost("cabin", upgrades.cabin)}
                              className={`w-full py-2 rounded-lg text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 ${
                                coins >= getUpgradeCost("cabin", upgrades.cabin)
                                  ? "bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black cursor-pointer"
                                  : "bg-slate-800 text-slate-500 cursor-not-allowed"
                              }`}
                            >
                              <span>UPGRADE CABIN</span>
                              <span>•</span>
                              <span className="flex items-center gap-0.5 font-bold">
                                <Coins className="w-3.5 h-3.5" />
                                {getUpgradeCost("cabin", upgrades.cabin)}
                              </span>
                            </button>
                          ) : (
                            <div className="w-full py-2 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-bold text-center rounded-lg flex items-center justify-center gap-1">
                              <Check className="w-3.5 h-3.5" /> MAX UPGRADE
                            </div>
                          )}
                        </div>

                      </div>

                      {/* Skins Selection Catalog */}
                      <div className="border-t border-slate-800 pt-5">
                        <h4 className="text-sm font-bold font-display text-slate-300 mb-3 uppercase tracking-wider">
                          Ambulance Custom Paint & Skins
                        </h4>

                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                          {SKINS_CATALOG.map((skin) => {
                            const isUnlocked = unlockedSkins.includes(skin.id);
                            const isActive = activeSkin === skin.id;

                            return (
                              <div 
                                key={skin.id}
                                className={`p-3 rounded-xl border flex flex-col justify-between gap-2.5 transition-all ${
                                  isActive 
                                    ? "bg-rose-950/30 border-rose-500" 
                                    : "bg-slate-950/50 border-slate-850"
                                }`}
                              >
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between">
                                    <span className="text-xs font-bold text-slate-200">{skin.name}</span>
                                    {isActive && <span className="text-[9px] bg-rose-500 text-white font-mono px-1.5 py-0.5 rounded font-bold uppercase">Active</span>}
                                  </div>
                                  <p className="text-[10px] text-slate-400 font-mono leading-tight">{skin.desc}</p>
                                </div>

                                {isUnlocked ? (
                                  <button
                                    id={`select-skin-${skin.id}`}
                                    onClick={() => selectOrBuySkin(skin.id, 0)}
                                    className={`w-full py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                                      isActive 
                                        ? "bg-slate-850 text-slate-400 border border-slate-700" 
                                        : "bg-slate-800 text-slate-200 hover:bg-slate-700"
                                    }`}
                                  >
                                    {isActive ? "Equipped" : "Equip Skin"}
                                  </button>
                                ) : (
                                  <button
                                    id={`buy-skin-${skin.id}`}
                                    onClick={() => selectOrBuySkin(skin.id, skin.cost)}
                                    disabled={coins < skin.cost}
                                    className={`w-full py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5 ${
                                      coins >= skin.cost
                                        ? "bg-yellow-500 hover:bg-yellow-400 text-slate-950 cursor-pointer font-black"
                                        : "bg-slate-800 text-slate-500 cursor-not-allowed"
                                    }`}
                                  >
                                    <span>Unlock</span>
                                    <span className="flex items-center gap-0.5 font-bold text-[11px]">
                                      <Coins className="w-3 h-3" />
                                      {skin.cost}
                                    </span>
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                    </motion.div>
                  )}

                  {/* TAB 3: LEADERBOARD RECORDS */}
                  {activeTab === "leaderboard" && (
                    <motion.div
                      key="tab-scores-content"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="bg-slate-900/60 border border-slate-800/80 rounded-3xl p-6 shadow-2xl backdrop-blur-md min-h-[400px] flex flex-col justify-between"
                    >
                      <div className="space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                          <div className="flex items-center gap-2.5">
                            <Trophy className="w-5 h-5 text-yellow-500" />
                            <h3 className="text-xl font-bold font-display text-white">CITY DISPATCH RECORDS</h3>
                          </div>
                          <button
                            id="reset-scores-action"
                            onClick={handleResetScores}
                            className="text-slate-400 hover:text-red-400 text-xs font-mono font-bold flex items-center gap-1.5 transition-all bg-slate-950/60 hover:bg-red-950/20 px-3 py-1.5 rounded-lg border border-slate-850 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Clear Board
                          </button>
                        </div>

                        <div className="space-y-2">
                          {highScores.length === 0 ? (
                            <p className="text-sm text-slate-500 italic py-8 text-center font-mono">No heroic missions saved to database yet.</p>
                          ) : (
                            highScores.map((hs, index) => (
                              <div 
                                key={index}
                                className="flex items-center justify-between p-3.5 bg-slate-950/50 rounded-xl border border-slate-850 font-mono text-sm"
                              >
                                <div className="flex items-center gap-3">
                                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-black ${
                                    index === 0 
                                      ? "bg-yellow-500/20 text-yellow-400 border border-yellow-400/30" 
                                      : (index === 1 ? "bg-slate-700/50 text-slate-300" : "bg-slate-850 text-slate-500")
                                  }`}>
                                    {index + 1}
                                  </span>
                                  <div className="flex flex-col">
                                    <span className="font-bold text-slate-200">{hs.name}</span>
                                    <span className="text-[10px] text-slate-500">Record Date: {hs.date}</span>
                                  </div>
                                </div>

                                <div className="text-right flex items-center gap-6">
                                  <div className="flex flex-col text-right">
                                    <span className="text-rose-400 font-bold">{hs.rescued} saved</span>
                                    <span className="text-[10px] text-slate-500">Level {hs.level || 1}</span>
                                  </div>
                                  <div className="h-6 w-[1px] bg-slate-850" />
                                  <span className="font-black text-emerald-400 text-lg tracking-tight">
                                    {hs.score} pts
                                  </span>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      <div className="bg-slate-950/40 p-3.5 rounded-2xl border border-slate-850 mt-4 text-xs font-mono text-slate-400 leading-normal flex items-start gap-2.5">
                        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                        <p>Score rates scale directly based on patient health status at hospital drop-off. Keep patient stretchers steady and avoid crashes to earn maximum scores!</p>
                      </div>

                    </motion.div>
                  )}

                  {/* TAB 4: CITY SETTINGS */}
                  {activeTab === "settings" && (
                    <motion.div
                      key="tab-settings-content"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="bg-slate-900/60 border border-slate-800/80 rounded-3xl p-6 shadow-2xl backdrop-blur-md min-h-[400px] flex flex-col justify-between"
                    >
                      <div className="space-y-6">
                        <div className="flex items-center gap-2.5 border-b border-slate-800 pb-3">
                          <SettingsIcon className="w-5 h-5 text-rose-500" />
                          <h3 className="text-xl font-bold font-display text-white">EMERGENCY DISPATCH SETTINGS</h3>
                        </div>

                        {/* 1. Difficulty selection */}
                        <div className="space-y-2.5">
                          <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                            City Traffic Difficulty
                          </label>
                          <div className="grid grid-cols-3 gap-3">
                            {(["easy", "normal", "hard"] as const).map((diff) => (
                              <button
                                id={`diff-${diff}`}
                                key={diff}
                                onClick={() => setDifficulty(diff)}
                                className={`py-3.5 rounded-xl border font-bold text-xs uppercase tracking-wider transition-all cursor-pointer ${
                                  difficulty === diff
                                    ? "bg-rose-500 text-white border-rose-400 shadow-md shadow-rose-500/10"
                                    : "bg-slate-950/50 border-slate-850 text-slate-400 hover:bg-slate-950 hover:text-white"
                                }`}
                              >
                                {diff}
                              </button>
                            ))}
                          </div>
                          <p className="text-[11px] text-slate-500 font-mono leading-relaxed mt-1">
                            {difficulty === "easy" && "• Easy mode: Lower traffic count, slower cars, patient health decays slowly."}
                            {difficulty === "normal" && "• Normal mode: Balanced street traffic and realistic patient decay."}
                            {difficulty === "hard" && "• Hard mode: Swarming traffic flows, speeding cars, rapid patient critical decay!"}
                          </p>
                        </div>

                        {/* 2. Audio Control */}
                        <div className="space-y-4 border-t border-slate-800 pt-5">
                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <h4 className="text-sm font-bold text-slate-200">Continuous Siren Audio</h4>
                              <p className="text-[11px] text-slate-400 font-mono">Continuous emergency sound effects during playing stages.</p>
                            </div>
                            <button
                              id="mute-setting-action"
                              onClick={toggleMute}
                              className={`px-5 py-2 rounded-xl font-bold text-xs font-mono transition-all border cursor-pointer ${
                                isMuted 
                                  ? "bg-slate-950 border-rose-500/30 text-rose-400" 
                                  : "bg-rose-500/10 border-rose-500/20 text-rose-400 hover:bg-rose-500/20"
                              }`}
                            >
                              {isMuted ? "MUTED" : "ENABLED"}
                            </button>
                          </div>

                          {!isMuted && (
                            <div className="space-y-3 bg-slate-950/40 p-4 rounded-2xl border border-slate-850/60">
                              <label className="block text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                                Active Siren Pattern / Tone
                              </label>
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                                {([
                                  { id: "wail", name: "Wail", desc: "Classic USA", pitch: "Slow Sweep" },
                                  { id: "yelp", name: "Yelp", desc: "Urgent Yelp", pitch: "Fast Sweep" },
                                  { id: "phaser", name: "Phaser", desc: "Tech Phaser", pitch: "Hyper Sweep" },
                                  { id: "hilo", name: "Hi-Lo", desc: "Euro Hi-Lo", pitch: "Two-Tone" },
                                ] as const).map((pat) => (
                                  <button
                                    id={`siren-pat-${pat.id}`}
                                    key={pat.id}
                                    onClick={() => changeSirenMode(pat.id)}
                                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between h-[82px] ${
                                      sirenMode === pat.id
                                        ? "bg-rose-500/10 border-rose-500 text-rose-400 shadow-lg shadow-rose-500/5"
                                        : "bg-slate-900/40 border-slate-850 text-slate-400 hover:border-slate-750 hover:text-white"
                                    }`}
                                  >
                                    <div className="flex items-center justify-between w-full">
                                      <span className="font-bold text-xs">{pat.name}</span>
                                      {sirenMode === pat.id && (
                                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
                                      )}
                                    </div>
                                    <div className="flex flex-col mt-2">
                                      <span className="text-[10px] text-slate-500 font-medium leading-tight">{pat.desc}</span>
                                      <span className="text-[9px] text-slate-400 font-mono mt-0.5">{pat.pitch}</span>
                                    </div>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* 3. Level administration */}
                        <div className="space-y-2.5 border-t border-slate-800 pt-5">
                          <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Cheat Diagnostics</h4>
                          <div className="flex items-center gap-3">
                            <button
                              id="cheat-coins"
                              onClick={() => handleAddCoins(250)}
                              className="px-4 py-2 bg-slate-950 border border-slate-850 text-xs font-mono text-slate-300 hover:text-white rounded-lg cursor-pointer transition-all"
                            >
                              +250 Free Coins
                            </button>
                            <button
                              id="cheat-reset"
                              onClick={() => {
                                setCoins(200);
                                setUpgrades({ engine: 0, steering: 0, armor: 0, cabin: 0 });
                                setUnlockedSkins(["classic"]);
                                setActiveSkin("classic");
                                setCurrentLevel(1);
                                setXp(0);
                                localStorage.clear();
                              }}
                              className="px-4 py-2 bg-red-950/30 border border-red-500/20 text-xs font-mono text-red-400 hover:bg-red-950/50 rounded-lg cursor-pointer transition-all"
                            >
                              Reset Local Stash
                            </button>
                          </div>
                        </div>

                      </div>

                      <div className="text-[10px] text-slate-500 font-mono border-t border-slate-800 pt-3">
                        DIAGNOSTICS: COMPILING PORT 3000 &bull; WEB AUDIO RUNS ON INTERACTIVE USER TRIGGER
                      </div>

                    </motion.div>
                  )}

                </AnimatePresence>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

        {/* PREMIUM MISSION COMPLETE / VICTORY OVERLAY */}
        <AnimatePresence>
          {gameState === GameState.WIN && (
            <motion.div
              id="victory-screen"
              initial={{ scale: 0.96, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              className="w-full max-w-md bg-slate-900/95 border border-emerald-500/40 p-8 rounded-3xl text-center shadow-[0_0_25px_rgba(16,185,129,0.15)] relative overflow-hidden backdrop-blur-xl"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/10 to-transparent pointer-events-none" />

              <div className="w-16 h-16 rounded-full bg-emerald-500/25 border border-emerald-400 flex items-center justify-center mx-auto mb-4 text-emerald-400">
                <Award className="w-8 h-8 animate-bounce" />
              </div>

              <h2 className="text-3xl font-black text-white tracking-tight font-display uppercase">Mission Complete!</h2>
              <p className="text-xs text-emerald-400 font-mono uppercase tracking-widest font-black mt-0.5">
                Dispatch Level {currentLevel} Cleared
              </p>

              {/* Star Rating Section */}
              <div className="flex justify-center items-center gap-2 my-4">
                {[1, 2, 3].map((star) => (
                  <Star 
                    id={`complete-star-${star}`}
                    key={star}
                    className={`w-8 h-8 transition-all duration-300 ${
                      star <= calculateStars() 
                        ? "text-yellow-400 fill-yellow-400 scale-110 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]" 
                        : "text-slate-700 fill-slate-850 scale-90"
                    }`}
                  />
                ))}
              </div>

              {/* Performance / Rewards Card */}
              <div className="my-5 bg-slate-950/80 border border-slate-850 rounded-2xl p-4 space-y-2 text-sm font-mono text-left">
                <div className="flex justify-between border-b border-slate-900 pb-1.5 text-xs">
                  <span className="text-slate-500">DRIVER UNIT:</span>
                  <span className="text-slate-300 font-bold">{playerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 text-xs">RESCUED CITIZENS:</span>
                  <span className="text-rose-400 font-bold">10 / 10</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 text-xs">TIME BONUS MULTIPLIER:</span>
                  <span className="text-cyan-400 font-bold">{timer}s remaining</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-slate-900">
                  <span className="text-slate-400 text-xs">COINS REWARD:</span>
                  <span className="text-yellow-400 font-bold flex items-center gap-1">
                    <Coins className="w-4 h-4" />
                    +{150 + timer * 2} Coins
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 text-xs">DISPATCH XP:</span>
                  <span className="text-teal-400 font-bold">
                    +{250 + timer * 3} XP
                  </span>
                </div>
                <div className="flex justify-between items-center pt-1.5 border-t border-slate-900 text-md font-black">
                  <span className="text-slate-300 text-xs">FINAL LEVEL SCORE:</span>
                  <span className="text-emerald-400">{score} PTS</span>
                </div>
              </div>

              {/* ER Physician Sign-off */}
              <div className="bg-slate-950/60 border border-emerald-500/20 rounded-2xl p-3 text-[10px] font-mono text-left space-y-1.5 text-emerald-400 mb-5">
                <div className="flex items-center gap-1.5 border-b border-emerald-500/10 pb-1 uppercase font-bold text-[8px] tracking-widest">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>Clinical Trauma Admissions Report</span>
                </div>
                <p className="text-slate-300 leading-normal">
                  Dr. Elizabeth Vance reports that all triaged casualties have been safely stabilized inside Surgical Suite B. Nurse Sarah Lin has cleared the triage bays. Excellent driving, dispatcher!
                </p>
              </div>

              {/* Navigation Action */}
              <div className="flex flex-col gap-2.5">
                <button
                  id="next-mission-button"
                  onClick={() => {
                    // Reward math
                    handleAddCoins(150 + timer * 2);
                    handleAddXp(250 + timer * 3);
                    handleNextLevel();
                  }}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold rounded-xl cursor-pointer shadow-lg shadow-emerald-600/20 transition-all text-sm uppercase tracking-wider font-display"
                >
                  Save Rewards & Next Mission
                </button>
                <button
                  id="win-retry-mission"
                  onClick={startGame}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-semibold rounded-xl cursor-pointer border border-slate-750 transition-all font-mono"
                >
                  Replay This Shift
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* STYLISH GAME OVER SCREEN */}
        <AnimatePresence>
          {gameState === GameState.GAME_OVER && (
            <motion.div
              id="gameover-screen"
              initial={{ scale: 0.96, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              className="w-full max-w-md bg-slate-900/95 border border-rose-500/40 p-8 rounded-3xl text-center shadow-[0_0_25px_rgba(244,63,94,0.15)] relative overflow-hidden backdrop-blur-xl"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-rose-500/10 to-transparent pointer-events-none" />

              <div className="w-16 h-16 rounded-full bg-rose-500/25 border border-rose-500 flex items-center justify-center mx-auto mb-4 text-rose-500">
                <ShieldAlert className="w-8 h-8 animate-pulse" />
              </div>

              <h2 className="text-3xl font-black text-white tracking-tight font-display uppercase">Unit Out of Service</h2>
              <p className="text-xs text-rose-400 font-mono uppercase tracking-widest font-black mt-0.5">
                {lives <= 0 ? "Chassis Destabilized" : "Emergency Countdown Timeout"}
              </p>

              {/* Performance stats summary */}
              <div className="my-5 bg-slate-950/80 border border-slate-850 rounded-2xl p-4 space-y-2 text-sm font-mono text-left">
                <div className="flex justify-between border-b border-slate-900 pb-1.5 text-xs">
                  <span className="text-slate-500">DRIVING HANDLE:</span>
                  <span className="text-slate-300 font-bold">{playerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 text-xs">RESCUED LEVEL CITIZENS:</span>
                  <span className="text-rose-400 font-bold">{patientsRescued} citizens</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 text-xs">DIFFICULTY MULTIPLIER:</span>
                  <span className="text-slate-300 uppercase font-bold">{difficulty}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-900 font-black">
                  <span className="text-slate-300 text-xs">ACHIEVED SCORE:</span>
                  <span className="text-emerald-400 text-md">{score} PTS</span>
                </div>
              </div>

              {/* ER Defibrillator Status Alert */}
              <div className="bg-slate-950/60 border border-rose-500/20 rounded-2xl p-3 text-[10px] font-mono text-left space-y-1.5 text-rose-400 mb-5">
                <div className="flex items-center gap-1.5 border-b border-rose-500/10 pb-1 uppercase font-bold text-[8px] tracking-widest">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
                  <span>Metropolitan Critical Alert Log</span>
                </div>
                <p className="text-slate-300 leading-normal">
                  Sirens silenced! Dispatcher unit telemetry is offline. Paramedic Marcus Roy is preheating backup engines while Chief Dr. Elizabeth Vance requests immediate reinforcements. Get back on the asphalt!
                </p>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-2.5">
                <button
                  id="retry-game-action"
                  onClick={startGame}
                  className="w-full py-3.5 bg-gradient-to-r from-red-600 to-rose-500 hover:from-red-500 hover:to-rose-400 text-white font-bold rounded-xl cursor-pointer shadow-lg shadow-rose-600/25 transition-all text-sm uppercase tracking-wider font-display"
                >
                  Retry Dispatch Re-entry
                </button>
                <button
                  id="gameover-home"
                  onClick={() => {
                    handleSaveScore();
                    setGameState(GameState.START);
                  }}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-semibold rounded-xl cursor-pointer border border-slate-750 transition-all font-mono"
                >
                  Return to Headquarters
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* 3. DETAIL TRAINING MANUAL OVERLAY HOW-TO */}
      <AnimatePresence>
        {showHowTo && (
          <div 
            id="how-to-modal" 
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative"
            >
              <div className="flex items-center gap-3 border-b border-slate-800 pb-3 mb-4">
                <Info className="w-5 h-5 text-rose-400" />
                <h3 className="text-lg font-bold font-display text-white">Metropolitan Dispatch Training Manual</h3>
              </div>

              <div className="space-y-4 text-xs text-slate-300 font-sans leading-normal">
                <div className="space-y-1">
                  <h4 className="font-bold text-yellow-400 font-mono uppercase tracking-wider text-[11px]">Steering Mechanics</h4>
                  <p className="text-slate-400">
                    Press <kbd className="bg-slate-950 px-1 py-0.5 rounded border border-slate-800 text-slate-300">W</kbd> to accelerate, and <kbd className="bg-slate-950 px-1 py-0.5 rounded border border-slate-800 text-slate-300">S</kbd> to reverse or brake. Use <kbd className="bg-slate-950 px-1 py-0.5 rounded border border-slate-800 text-slate-300">A / D</kbd> to rotate. Turning uses true angular physics—the faster you are rolling, the tighter you steer!
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-rose-400 font-mono uppercase tracking-wider text-[11px]">SOS Patient Alarms</h4>
                  <p className="text-slate-400">
                    Locate pulsing critical health circles on roadsides or park sidewalks. Board up to <span className="text-rose-400 font-bold">Cabin Capacity limit</span> stretchers. Watch out: their health decays over time! Deliver them to the <span className="text-emerald-400 font-bold">flashing green Hospital Bay</span> before they expire!
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-emerald-400 font-mono uppercase tracking-wider text-[11px]">Street Obstructions & AI</h4>
                  <p className="text-slate-400">
                    Traffic AI cars drive along highways, stop at intersection red lights, and yield when your sirens approach! Crashing into buildings, water blocks, or traffic cars will damage your machinery. 
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-cyan-400 font-mono uppercase tracking-wider text-[11px]">Garage Customization Shop</h4>
                  <p className="text-slate-400">
                    Unlock engine parts, tires steering grips, chassis shields, and premium neon decals using coins earned from successful missions!
                  </p>
                </div>
              </div>

              <button
                id="close-manual"
                onClick={() => setShowHowTo(false)}
                className="mt-6 w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold rounded-xl cursor-pointer transition-all border border-slate-750"
              >
                Close Dispatch Manual
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FOOTER METADATA SYSTEM LINES */}
      <footer id="footer-branding" className="w-full max-w-5xl mt-5 border-t border-slate-900 pt-3 text-center text-[10px] text-slate-500 font-mono">
        DISPATCH CORES TERMINAL ONLINE &bull; SECURED PREVIEW PROTOCOLS &bull; RESCUE DEPLOYMENT
      </footer>
    </div>
  );
}
