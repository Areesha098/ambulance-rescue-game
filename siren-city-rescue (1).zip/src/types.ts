/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Point {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export enum GameState {
  START = "START",
  PLAYING = "PLAYING",
  PAUSED = "PAUSED",
  GAME_OVER = "GAME_OVER",
  WIN = "WIN"
}

export interface Ambulance {
  x: number;
  y: number;
  width: number;
  height: number;
  angle: number; // in radians
  speed: number;
  maxSpeed: number;
  acceleration: number;
  deceleration: number;
  friction: number;
  steerSpeed: number;
  lives: number;
  maxLives: number;
  invincibleTime: number; // in frames or ms
  carryingPatients: Patient[];
  maxCapacity: number;
  skin: string;
}

export interface Patient {
  id: string;
  x: number;
  y: number;
  name: string;
  severity: "mild" | "moderate" | "severe"; // different scoring/timer reward
  pickedUp: boolean;
  sosPulse: number; // animation value
  health: number; // 0 to 100
  maxHealth: number;
  locationName: string;
}

export interface TrafficCar {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  angle: number;
  speed: number;
  targetSpeed: number;
  color: string;
  direction: "left" | "right" | "up" | "down";
  lane: number; // street offset
  braking: boolean;
}

export interface Pedestrian {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  angle: number;
  targetX: number;
  targetY: number;
}

export interface TrafficLight {
  id: string;
  x: number;
  y: number;
  state: "red" | "yellow" | "green";
  timer: number;
}

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: "building" | "park" | "water" | "tree" | "fence" | "hospital" | "streetlight";
  color?: string;
  icon?: string;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number; // 0 to 1
  decay: number;
  type: "smoke" | "spark" | "heart" | "plus" | "skid" | "siren_red" | "siren_blue";
}

export interface SoundEffectOption {
  frequency?: number;
  duration?: number;
  type?: OscillatorType;
}
