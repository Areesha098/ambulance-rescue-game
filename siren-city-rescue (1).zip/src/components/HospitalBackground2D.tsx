import React from "react";
import { motion } from "motion/react";

export default function HospitalBackground2D() {
  return (
    <div
      id="hospital-background-2d-root"
      className="absolute inset-0 w-full h-full bg-gradient-to-tr from-blue-50 via-sky-50 to-white overflow-hidden pointer-events-none select-none z-0 flex flex-col justify-between"
    >
      {/* 1. BRIGHT HOSPITAL SKY & LIGHTING EFFECT */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(14,165,233,0.03)_1.5px,transparent_1.5px),linear-gradient(90deg,rgba(14,165,233,0.03)_1.5px,transparent_1.5px)] bg-[size:24px_24px] pointer-events-none" />

      {/* Glowing sun/ambient beam from top-right */}
      <div className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-cyan-200/20 blur-[120px]" />
      <div className="absolute top-20 left-10 w-96 h-96 rounded-full bg-blue-100/30 blur-[100px]" />

      {/* ========================================================= */}
      {/* 2. THE BACKGROUND LANDSCAPE & HOSPITAL STRUCTURE (OUTDOORS) */}
      {/* ========================================================= */}
      <div className="absolute inset-x-0 bottom-0 h-[48%] bg-slate-200/80 border-t-4 border-slate-300">
        {/* Paved asphalt road driveway for ambulances */}
        <div className="w-full h-full bg-gradient-to-b from-slate-200 via-slate-100 to-slate-200 relative">
          
          {/* Yellow Road Hash Lines */}
          <div className="absolute top-4 left-[10%] right-[45%] h-2 bg-[repeating-linear-gradient(90deg,transparent,transparent_12px,#eab308_12px,#eab308_24px)] opacity-60" />

          {/* Labeled Ambulance Parking Bays (Left/Center bottom area) */}
          <div className="absolute bottom-6 left-[8%] w-[260px] h-[130px] border-2 border-dashed border-yellow-500/40 rounded-2xl bg-slate-300/30 flex flex-col justify-between p-3">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-black font-mono text-yellow-600 tracking-wider">AMBULANCE BAY 01</span>
              <span className="text-[9px] font-bold font-mono px-1.5 py-0.5 bg-yellow-500/10 text-yellow-600 border border-yellow-500/20 rounded uppercase">KEEP CLEAR</span>
            </div>
            
            {/* Labeled Ground text */}
            <div className="text-center font-black font-mono text-[11px] text-yellow-600/40 tracking-widest uppercase">
              RESCUE UNIT PARKING ONLY
            </div>

            {/* Pavement yellow grid indicators */}
            <div className="h-2 w-full bg-[repeating-linear-gradient(-45deg,#eab308_0,#eab308_6px,transparent_6px,transparent_12px)] opacity-20 rounded" />
          </div>

          <div className="absolute bottom-6 left-[34%] w-[220px] h-[130px] border-2 border-dashed border-blue-500/30 rounded-2xl bg-slate-300/20 flex flex-col justify-between p-3 hidden xl:flex">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-black font-mono text-blue-600 tracking-wider">EMERGENCY BAY 02</span>
              <span className="text-[9px] font-bold font-mono px-1.5 py-0.5 bg-blue-500/10 text-blue-600 border border-blue-500/20 rounded uppercase">STANDBY</span>
            </div>
            <div className="text-center font-black font-mono text-[11px] text-blue-600/30 tracking-widest uppercase">
              CRITICAL TRANSFER
            </div>
            <div className="h-2 w-full bg-[repeating-linear-gradient(-45deg,#3b82f6_0,#3b82f6_6px,transparent_6px,transparent_12px)] opacity-10 rounded" />
          </div>

          {/* ========================================================= */}
          {/* PARKED 2D AMBULANCE VECTOR (Left Bay) */}
          {/* ========================================================= */}
          <div className="absolute bottom-10 left-[11%] scale-110 z-10 hidden sm:block">
            <motion.div 
              animate={{ y: [0, -1, 0] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
              className="relative w-40 h-24"
            >
              {/* Ambulance Chassis */}
              <div className="absolute bottom-4 left-0 w-36 h-14 bg-white border border-slate-300 rounded-lg shadow-md" />
              {/* Cabin Driver glass */}
              <div className="absolute bottom-[26px] right-2 w-10 h-10 bg-sky-200 border border-sky-300 rounded-tr-xl rounded-br-sm" />
              {/* Cabin partition line */}
              <div className="absolute bottom-4 right-12 w-[1px] h-14 bg-slate-200" />
              {/* Front bumper */}
              <div className="absolute bottom-4 right-1 w-2 h-4 bg-slate-400 rounded-r" />
              {/* Rear bumper */}
              <div className="absolute bottom-4 left-0 w-1.5 h-6 bg-slate-400 rounded-l" />

              {/* Red Cross Medical Livery */}
              <div className="absolute bottom-7 left-12 w-10 h-10 flex items-center justify-center">
                <div className="w-8 h-2 bg-red-500 rounded-sm absolute" />
                <div className="w-2 h-8 bg-red-500 rounded-sm absolute" />
              </div>
              <div className="absolute bottom-[44px] left-4 text-[9px] font-black font-mono text-red-500 tracking-wider uppercase">AMBULANCE</div>
              {/* Side stripes */}
              <div className="absolute bottom-6 left-0 right-12 h-1.5 bg-red-500" />
              <div className="absolute bottom-4.5 left-0 right-12 h-1 bg-cyan-400" />

              {/* Beacon Lights (Flashing red/blue) */}
              <div className="absolute top-7 left-8 flex gap-1">
                <div className="w-3 h-2 bg-red-500 rounded-t animate-pulse" style={{ animationDuration: "0.3s" }} />
                <div className="w-3 h-2 bg-blue-500 rounded-t animate-pulse" style={{ animationDuration: "0.4s", animationDelay: "0.15s" }} />
              </div>
              
              {/* Beacon light bloom glow */}
              <div className="absolute top-1 left-5 w-12 h-12 bg-red-500/10 rounded-full blur-md animate-ping" style={{ animationDuration: "1s" }} />
              <div className="absolute top-1 left-9 w-12 h-12 bg-blue-500/10 rounded-full blur-md animate-ping" style={{ animationDuration: "1.2s", animationDelay: "0.2s" }} />

              {/* Wheels */}
              <div className="absolute bottom-1 left-6 w-7 h-7 bg-slate-800 rounded-full border-4 border-slate-300 flex items-center justify-center">
                <div className="w-2 h-2 bg-slate-400 rounded-full" />
              </div>
              <div className="absolute bottom-1 right-8 w-7 h-7 bg-slate-800 rounded-full border-4 border-slate-300 flex items-center justify-center">
                <div className="w-2 h-2 bg-slate-400 rounded-full" />
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 3. THE EMERGENCY ENTRANCE & HOSPITAL BUILDING FACADE (Left/Center) */}
      {/* ========================================================= */}
      <div className="absolute bottom-[40%] left-[5%] w-[42%] h-[50%] bg-gradient-to-b from-white to-slate-50 border-r-8 border-l-8 border-t-8 border-slate-200 shadow-xl rounded-t-3xl z-0 flex flex-col justify-between p-4">
        {/* Upper structural details */}
        <div className="w-full flex justify-between items-start">
          {/* Hospital Brand Cross */}
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-red-500 rounded-xl flex items-center justify-center shadow-md shadow-red-500/20 relative">
              <div className="w-6 h-1.5 bg-white rounded-sm absolute" />
              <div className="w-1.5 h-6 bg-white rounded-sm absolute" />
            </div>
            <div className="flex flex-col">
              <span className="text-[12px] font-black font-display text-slate-800 tracking-tight leading-none">METROPOLITAN</span>
              <span className="text-[9px] font-mono text-cyan-600 font-bold tracking-wider uppercase">General Hospital</span>
            </div>
          </div>

          {/* Building glass window panels */}
          <div className="flex gap-2">
            <div className="w-8 h-12 bg-sky-100/70 border border-sky-200 rounded-lg flex flex-col justify-between p-1">
              <div className="h-0.5 w-full bg-sky-200/50" />
              <div className="h-0.5 w-full bg-sky-200/50" />
            </div>
            <div className="w-8 h-12 bg-sky-100/70 border border-sky-200 rounded-lg flex flex-col justify-between p-1">
              <div className="h-0.5 w-full bg-sky-200/50" />
              <div className="h-0.5 w-full bg-sky-200/50" />
            </div>
            <div className="w-8 h-12 bg-sky-100/70 border border-sky-200 rounded-lg flex flex-col justify-between p-1 hidden lg:block">
              <div className="h-0.5 w-full bg-sky-200/50" />
              <div className="h-0.5 w-full bg-sky-200/50" />
            </div>
          </div>
        </div>

        {/* Big Neon Red EMERGENCY Entrance Sign */}
        <div className="w-full bg-red-600/5 border border-red-500/20 rounded-xl p-2.5 text-center flex flex-col items-center justify-center relative shadow-sm my-1">
          <div className="absolute top-0.5 left-2 w-2 h-2 rounded-full bg-red-500 animate-ping" />
          
          <h3 className="text-sm md:text-md font-black tracking-widest text-red-600 font-display uppercase animate-pulse">
            🚨 EMERGENCY ENTRANCE
          </h3>
          <span className="text-[8px] font-mono font-bold text-red-500 tracking-widest uppercase">
            Trauma Admissions Hub &bull; sirens active
          </span>
        </div>

        {/* Automated Double Sliding Glass Doors */}
        <div className="w-[180px] h-[100px] bg-slate-100 border-t-4 border-l-4 border-r-4 border-slate-300 mx-auto relative rounded-t-xl flex justify-between overflow-hidden shadow-inner">
          {/* Glass background */}
          <div className="absolute inset-0 bg-sky-100/30 flex justify-between" />

          {/* Left sliding door */}
          <div className="w-[48%] h-full bg-sky-200/35 border-r border-slate-300 flex items-center justify-end pr-1 relative transition-all">
            {/* Medical safety logo */}
            <div className="w-5 h-5 border border-cyan-400/50 rounded-full flex items-center justify-center text-cyan-500 text-[8px] font-black font-mono scale-90">H</div>
          </div>
          {/* Right sliding door */}
          <div className="w-[48%] h-full bg-sky-200/35 border-l border-slate-300 flex items-center justify-start pl-1 relative transition-all">
            {/* Medical safety logo */}
            <div className="w-5 h-5 border border-cyan-400/50 rounded-full flex items-center justify-center text-cyan-500 text-[8px] font-black font-mono scale-90">H</div>
          </div>

          {/* Door overhead sensor (glowing green/yellow) */}
          <div className="absolute top-1 left-1/2 -translate-x-1/2 w-6 h-1.5 bg-slate-600 rounded-full flex justify-center items-center">
            <span className="w-1 h-1 rounded-full bg-emerald-400 animate-ping" />
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 4. THE INDOOR RECEPTION, TRIAGE & CLINICAL SECTOR (Right) */}
      {/* ========================================================= */}
      <div className="absolute bottom-[40%] right-[5%] w-[42%] h-[53%] bg-white border-l-8 border-r-8 border-t-8 border-cyan-100 shadow-xl rounded-t-3xl z-10 flex flex-col justify-between p-4 overflow-hidden">
        {/* Background grid wallpaper effect */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.02)_1px,transparent_1px)] bg-[size:12px_12px] pointer-events-none" />

        {/* Indoor Area Header */}
        <div className="w-full flex justify-between items-center border-b border-slate-100 pb-2 relative z-10">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-[10px] font-black font-mono text-cyan-600 tracking-wider uppercase">CLINICAL TRIAGE LEVEL</span>
          </div>
          <span className="text-[8px] font-mono text-slate-400 font-bold bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100 uppercase">STATION B</span>
        </div>

        {/* Central visual assets grid (ECG monitor, Reception desk, patient stretchers) */}
        <div className="w-full grid grid-cols-12 gap-3 relative z-10 flex-1 my-2">
          
          {/* COLUMN LEFT: HEART RATE MONITOR (ECG) & MEDICAL EQUIPMENT */}
          <div className="col-span-6 flex flex-col gap-2.5 justify-center">
            
            {/* Pulse Rate Display Box */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-2 shadow-inner relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-900 pb-1">
                <span className="text-[8px] font-mono font-bold text-slate-500 uppercase">ECG MONITOR 01</span>
                <span className="text-[9px] font-mono font-bold text-emerald-400 animate-pulse">84 BPM</span>
              </div>
              
              {/* Dynamic Beating Heart rate line */}
              <div className="h-8 w-full relative flex items-center overflow-hidden">
                <svg className="w-full h-full text-emerald-400" viewBox="0 0 100 30" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M0 15 L20 15 L25 5 L30 25 L35 15 L50 15 L53 15 L58 1 L63 29 L68 15 L80 15 L100 15" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                {/* Glowing laser sweep block */}
                <div className="absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-slate-950 to-transparent" />
              </div>
            </div>

            {/* IV Stand fluid drip */}
            <div className="flex items-center gap-2 bg-cyan-50/50 border border-cyan-100 rounded-xl p-1.5">
              {/* IV Bag vector */}
              <svg className="w-5 h-8 text-cyan-500 shrink-0" fill="none" viewBox="0 0 12 24" stroke="currentColor" strokeWidth="1.5">
                <path d="M6 1 L6 3 M2 5 L10 5 L10 18 C10 20, 2 20, 2 18 Z M6 18 L6 23" />
                <circle cx="6" cy="11" r="1" fill="currentColor" className="animate-ping" style={{ animationDuration: "1.5s" }} />
              </svg>
              <div className="flex flex-col">
                <span className="text-[8px] font-mono font-extrabold text-cyan-600 uppercase leading-none">IV DRIP</span>
                <span className="text-[7px] text-slate-500 font-mono mt-0.5">Saline active</span>
              </div>
            </div>

            {/* Wall Mounted Defibrillator box */}
            <div className="flex items-center gap-2 bg-rose-50/50 border border-rose-100 rounded-xl p-1.5">
              <div className="w-5 h-6 bg-rose-500 text-white font-extrabold rounded flex items-center justify-center text-[10px] shadow-sm shrink-0">
                ⚡
              </div>
              <div className="flex flex-col">
                <span className="text-[8px] font-mono font-extrabold text-rose-500 uppercase leading-none">AED STATION</span>
                <span className="text-[7px] text-slate-500 font-mono mt-0.5">READY FOR SHOCK</span>
              </div>
            </div>
          </div>

          {/* COLUMN RIGHT: RECEPTION COUNTER desk & medical records */}
          <div className="col-span-6 flex flex-col justify-end relative">
            
            {/* Curved Reception counter wood/metal design */}
            <div className="w-full h-10 bg-gradient-to-r from-cyan-100 to-sky-100 border border-cyan-200 rounded-t-2xl shadow-sm relative flex items-center px-2.5 justify-between">
              <span className="text-[8px] font-mono font-black text-cyan-700 tracking-wider">RECEPTION</span>
              
              {/* Desktop computer screen */}
              <div className="w-8 h-6 bg-slate-700 border border-slate-600 rounded-md relative flex flex-col items-center justify-between p-0.5 shadow">
                <div className="w-full h-3 bg-sky-200 rounded-sm flex items-center justify-center">
                  <span className="text-[5px] font-mono text-slate-600">ID:911</span>
                </div>
                <div className="w-1.5 h-1.5 bg-slate-600 rounded-sm" />
                <div className="w-4 h-0.5 bg-slate-500 rounded-sm" />
              </div>
            </div>

            {/* Waiting Sofa next to reception */}
            <div className="w-[110px] h-4.5 bg-slate-300 border-t border-slate-400 rounded-sm relative mt-2 self-start flex justify-between px-1">
              <div className="w-2 h-4.5 bg-slate-400 rounded-sm" />
              <div className="w-2 h-4.5 bg-slate-400 rounded-sm" />
              <div className="w-2 h-4.5 bg-slate-400 rounded-sm" />
              <div className="w-2 h-4.5 bg-slate-400 rounded-sm" />
            </div>
          </div>
        </div>

        {/* 2D Wheelchair & Stretcher Row representation (Center-bottom of clinical bay) */}
        <div className="w-full flex gap-4 border-t border-slate-100 pt-3 relative z-10">
          
          {/* Crisp 2D Stretcher */}
          <div className="flex items-center gap-2 bg-blue-50/40 border border-blue-100 rounded-xl p-2 flex-1">
            {/* Stretcher Vector SVG */}
            <svg className="w-8 h-6 text-cyan-600 shrink-0" fill="none" viewBox="0 0 32 24" stroke="currentColor" strokeWidth="1.5">
              {/* Mattress support */}
              <rect x="2" y="8" width="28" height="3" rx="1" fill="currentColor" />
              {/* Backrest pillow */}
              <rect x="2" y="5" width="6" height="3" rx="0.5" />
              {/* Metal support frame (Cross leg braces) */}
              <line x1="8" y1="11" x2="22" y2="21" />
              <line x1="22" y1="11" x2="8" y2="21" />
              {/* Ground caster wheels */}
              <circle cx="8" cy="21" r="2.5" fill="currentColor" />
              <circle cx="22" cy="21" r="2.5" fill="currentColor" />
            </svg>
            <div className="flex flex-col">
              <span className="text-[8px] font-mono font-bold text-slate-700">STRETCHER BED</span>
              <span className="text-[7px] text-slate-400 font-mono">Mobile Bed Ready</span>
            </div>
          </div>

          {/* Crisp 2D Wheelchair */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-2 flex-1">
            {/* Wheelchair Vector SVG */}
            <svg className="w-8 h-6 text-slate-500 shrink-0" fill="none" viewBox="0 0 32 24" stroke="currentColor" strokeWidth="1.5">
              {/* Back seat rest */}
              <path d="M8 3 L8 15 L22 15" strokeLinecap="round" strokeLinejoin="round" />
              {/* Handlebar */}
              <path d="M5 4 L8 4" strokeLinecap="round" />
              {/* Arm rest */}
              <path d="M12 11 L19 11" strokeLinecap="round" />
              {/* Foot rest */}
              <path d="M22 15 L24 19 L26 19" strokeLinecap="round" />
              {/* Huge main wheel */}
              <circle cx="12" cy="15" r="5" fill="none" stroke="currentColor" strokeWidth="2" />
              <circle cx="12" cy="15" r="1.5" fill="currentColor" />
              {/* Front small castor wheel */}
              <circle cx="24" cy="20" r="2" fill="currentColor" />
            </svg>
            <div className="flex flex-col">
              <span className="text-[8px] font-mono font-bold text-slate-700">WHEELCHAIR</span>
              <span className="text-[7px] text-slate-400 font-mono">Chrome Comfort</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 5. 2D CHARACTERS: CLINICAL TRAUMA STAFF (DOCTORS & NURSES) & PATIENTS */}
      {/* ========================================================= */}
      {/* Placement on bottom/floor areas (absolute coordinates) */}

      {/* Doctor (Triage lead in white coat near Entrance/Triage) */}
      <div className="absolute bottom-[33%] right-[32%] z-25">
        <motion.div 
          animate={{ y: [0, -1.5, 0] }}
          transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
          className="flex flex-col items-center"
        >
          {/* Stethoscope, coat, stethoscope vector face */}
          <div className="relative w-7 h-16 flex flex-col items-center">
            {/* Stethoscope around neck display */}
            <div className="absolute top-[18px] w-4 h-3 border-b border-cyan-400 rounded-b-md" />
            {/* Hair head */}
            <div className="w-5 h-5 bg-[#ffdbac] rounded-full border border-slate-300 relative">
              <div className="absolute top-0 inset-x-0 h-1.5 bg-slate-700 rounded-t-full" />
              {/* Friendly Eyes */}
              <div className="absolute top-2.5 left-1 w-0.5 h-0.5 bg-slate-900 rounded-full" />
              <div className="absolute top-2.5 right-1 w-0.5 h-0.5 bg-slate-900 rounded-full" />
              {/* Medical face mask */}
              <div className="absolute bottom-0.5 inset-x-1 h-2 bg-sky-100 rounded border border-sky-300 flex items-center justify-center">
                <span className="text-[3px] font-mono text-cyan-500 scale-50">+</span>
              </div>
            </div>
            {/* Doctors Coat */}
            <div className="w-6 h-10 bg-white border border-slate-300 rounded-t-md relative flex flex-col items-center">
              <div className="w-2 h-full bg-cyan-600" /> {/* Inside Scrubs */}
              {/* Stethoscope chest piece */}
              <div className="absolute top-2 left-1.5 w-1 h-3 bg-slate-500 rounded" />
              {/* Hands holding clipboard */}
              <div className="absolute bottom-2 inset-x-1.5 h-3 bg-[#eab308] border border-yellow-600 rounded-sm flex items-center justify-center text-[5px] font-mono text-white">
                📋
              </div>
            </div>
          </div>
          <span className="text-[8px] font-black font-mono bg-white/90 border border-slate-200 text-slate-800 px-1 py-0.5 rounded mt-1 shadow-xs">
            Dr. Elizabeth
          </span>
        </motion.div>
      </div>

      {/* Nurse (Triage assistant in blue scrubs near Reception) */}
      <div className="absolute bottom-[33%] right-[11%] z-25">
        <motion.div 
          animate={{ y: [0, -1, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut", delay: 0.3 }}
          className="flex flex-col items-center"
        >
          <div className="relative w-7 h-16 flex flex-col items-center">
            {/* Cap */}
            <div className="absolute -top-1 w-4 h-2.5 bg-cyan-500 rounded-t-full" />
            {/* Face */}
            <div className="w-5 h-5 bg-[#f1c27d] rounded-full border border-slate-300 relative">
              <div className="absolute top-1 inset-x-0 h-1.5 bg-amber-800 rounded-t-full" />
              <div className="absolute top-2.5 left-1 w-0.5 h-0.5 bg-slate-900 rounded-full" />
              <div className="absolute top-2.5 right-1 w-0.5 h-0.5 bg-slate-900 rounded-full" />
            </div>
            {/* Scrubs body */}
            <div className="w-5.5 h-10 bg-cyan-400 border border-cyan-500 rounded-t-md relative flex flex-col items-center justify-center">
              <span className="text-[7px] font-black font-mono text-white scale-75">+</span>
              {/* Pocket */}
              <div className="absolute bottom-2.5 right-1 w-1.5 h-2 bg-cyan-500 rounded-xs" />
            </div>
          </div>
          <span className="text-[8px] font-black font-mono bg-white/90 border border-slate-200 text-slate-800 px-1 py-0.5 rounded mt-1 shadow-xs">
            Nurse Sarah
          </span>
        </motion.div>
      </div>

      {/* Patient on Wheelchair (Sitting near waiting couch) */}
      <div className="absolute bottom-[28%] right-[22%] z-25">
        <motion.div 
          animate={{ y: [0, -0.8, 0] }}
          transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
          className="flex flex-col items-center"
        >
          <div className="relative w-6 h-14 flex flex-col items-center">
            {/* Face */}
            <div className="w-4.5 h-4.5 bg-[#e0ac69] rounded-full border border-slate-300 relative">
              <div className="absolute top-0 inset-x-0 h-1.5 bg-yellow-900 rounded-t-full" />
              <div className="absolute top-2.5 left-1 w-0.5 h-0.5 bg-slate-900 rounded-full" />
              <div className="absolute top-2.5 right-1 w-0.5 h-0.5 bg-slate-900 rounded-full" />
            </div>
            {/* Casual clothing shirt */}
            <div className="w-5 h-8 bg-sky-500 border border-sky-600 rounded-t-md relative flex items-center justify-center">
              {/* Arm cast bandage detail */}
              <div className="absolute top-2 left-0.5 w-1.5 h-4 bg-white border border-slate-300 rounded rotate-[15deg] flex items-center justify-center text-[4px] font-mono text-slate-500">
                +
              </div>
            </div>
            {/* Leg cast plaster bandage detail */}
            <div className="absolute -bottom-1 w-3.5 h-4 bg-white border border-slate-200 rounded" />
          </div>
          <span className="text-[8px] font-bold font-mono bg-white/90 border border-slate-200 text-blue-600 px-1 py-0.5 rounded mt-1 shadow-xs uppercase tracking-wide">
            Patient Liam
          </span>
        </motion.div>
      </div>

      {/* ========================================================= */}
      {/* 6. LANDSCAPED GARDENS, EVERGREEN TREES & OUTDOOR LIGHTS */}
      {/* ========================================================= */}
      
      {/* Flanking Tree (Left Side Edge) */}
      <div className="absolute bottom-[36%] left-[1.5%] z-10 hidden md:block">
        <div className="relative flex flex-col items-center">
          {/* Layered pine tree SVG */}
          <svg className="w-16 h-28 text-emerald-600" viewBox="0 0 40 80" fill="currentColor">
            {/* Leaves Layer 1 (Bottom) */}
            <polygon points="20,10 5,45 35,45" />
            {/* Leaves Layer 2 (Middle) */}
            <polygon points="20,5 8,35 32,35" />
            {/* Leaves Layer 3 (Top) */}
            <polygon points="20,0 12,25 28,25" />
            {/* Tree Trunk */}
            <rect x="17" y="45" width="6" height="20" fill="#78350f" />
            {/* Planter Pot box */}
            <rect x="13" y="62" width="14" height="12" rx="2" fill="#4b5563" />
          </svg>
        </div>
      </div>

      {/* Flanking Tree (Center Side Division between Building & Indoor Bay) */}
      <div className="absolute bottom-[36%] left-[48%] z-10 hidden lg:block">
        <div className="relative flex flex-col items-center">
          {/* Round deciduous leafy tree */}
          <svg className="w-16 h-28 text-emerald-500" viewBox="0 0 40 80" fill="currentColor">
            {/* Leaves canopy */}
            <circle cx="20" cy="22" r="18" />
            <circle cx="12" cy="18" r="12" />
            <circle cx="28" cy="18" r="12" />
            {/* Trunk */}
            <rect x="18" y="36" width="4" height="25" fill="#78350f" />
            {/* Rounded pot */}
            <ellipse cx="20" cy="60" rx="9" ry="6" fill="#374151" />
          </svg>
        </div>
      </div>

      {/* Hedges bordering building grounds */}
      <div className="absolute bottom-[38%] left-[2%] w-[48%] h-5 bg-gradient-to-r from-emerald-600 to-teal-500 border border-emerald-700/30 rounded-t-xl z-10 opacity-75 pointer-events-none" />

      {/* ========================================================= */}
      {/* OUTDOOR POST LIGHT LAMP CASTING SOFT GLOW */}
      {/* ========================================================= */}
      <div className="absolute bottom-[36%] left-[45%] z-20">
        <div className="relative w-8 h-32 flex flex-col items-center">
          {/* Metal pole */}
          <div className="w-1 h-24 bg-slate-400" />
          {/* Lamp bulb enclosure */}
          <div className="w-4 h-4 bg-slate-600 rounded-full flex items-center justify-center relative -mt-1 shadow">
            <div className="w-2.5 h-2.5 bg-yellow-300 rounded-full animate-pulse" />
          </div>
          {/* Glowing Cone cast from the bulb */}
          <div className="absolute top-[88px] w-48 h-28 bg-yellow-400/10 blur-[15px] rounded-b-full pointer-events-none origin-top scale-x-50" style={{ clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)" }} />
        </div>
      </div>

      <div className="absolute bottom-[36%] left-[2%] z-20 hidden xl:block">
        <div className="relative w-8 h-32 flex flex-col items-center">
          {/* Metal pole */}
          <div className="w-1 h-24 bg-slate-400" />
          {/* Lamp bulb enclosure */}
          <div className="w-4 h-4 bg-slate-600 rounded-full flex items-center justify-center relative -mt-1 shadow">
            <div className="w-2.5 h-2.5 bg-yellow-300 rounded-full animate-pulse" />
          </div>
          {/* Glowing Cone */}
          <div className="absolute top-[88px] w-48 h-28 bg-yellow-400/10 blur-[15px] rounded-b-full pointer-events-none origin-top scale-x-50" style={{ clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)" }} />
        </div>
      </div>

      {/* ========================================================= */}
      {/* CEILING SPOTLIGHT INDICATORS (Indoor Bay area) */}
      {/* ========================================================= */}
      <div className="absolute bottom-[92%] right-[10%] w-6 h-1.5 bg-slate-300 rounded-b-md z-25 flex items-center justify-center">
        <div className="w-3 h-3 bg-cyan-300/40 rounded-full blur-xs animate-ping" />
      </div>
      <div className="absolute bottom-[92%] right-[30%] w-6 h-1.5 bg-slate-300 rounded-b-md z-25 flex items-center justify-center">
        <div className="w-3 h-3 bg-cyan-300/40 rounded-full blur-xs animate-ping" />
      </div>
    </div>
  );
}
