/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import { 
  Point, 
  Rect, 
  GameState, 
  Ambulance, 
  Patient, 
  TrafficCar, 
  Pedestrian,
  TrafficLight,
  Obstacle, 
  Particle 
} from "../types";
import { soundManager } from "../utils/sound";

interface GameCanvasProps {
  gameState: GameState;
  score: number;
  lives: number;
  patientsRescued: number;
  timer: number;
  isMuted: boolean;
  onScoreChange: (score: number) => void;
  onLivesChange: (lives: number) => void;
  onPatientsRescued: (count: number) => void;
  onTimerChange: (timer: number) => void;
  onGameStateChange: (state: GameState) => void;
  onPatientCountChange: (currentCarrying: number) => void;
  
  // Premium Additions
  activeSkin: string;
  upgrades: {
    engine: number;
    steering: number;
    armor: number;
    cabin: number;
  };
  difficulty: "easy" | "normal" | "hard";
  onAddCoins: (amount: number) => void;
  onAddXp: (amount: number) => void;
  currentLevel: number;
  sirenMode: "wail" | "yelp" | "phaser" | "hilo";
  onSirenModeChange: (mode: "wail" | "yelp" | "phaser" | "hilo") => void;
}

const MAP_WIDTH = 1600;
const MAP_HEIGHT = 1600;

export const GameCanvas: React.FC<GameCanvasProps> = ({
  gameState,
  score,
  lives,
  patientsRescued,
  timer,
  isMuted,
  onScoreChange,
  onLivesChange,
  onPatientsRescued,
  onTimerChange,
  onGameStateChange,
  onPatientCountChange,
  activeSkin,
  upgrades,
  difficulty,
  onAddCoins,
  onAddXp,
  currentLevel,
  sirenMode,
  onSirenModeChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Dimensions and Canvas HUD states
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [hudMessage, setHudMessage] = useState<string | null>("Dispatch Initialized. Press WASD to Drive!");
  const [currentSpeedKmh, setCurrentSpeedKmh] = useState<number>(0);
  
  // Refs to maintain frame states without triggering React renders inside the 60fps loop
  const requestRef = useRef<number | null>(null);
  const keys = useRef<{ [key: string]: boolean }>({});
  
  // Screen shake intensity
  const screenShakeRef = useRef<number>(0);
  
  // Ambulance stats computed with upgrades
  const getMaxSpeed = () => {
    // base speed is 6.5, each upgrade tier adds +0.75 max speed
    return 6.5 + upgrades.engine * 0.75;
  };
  const getSteerSpeed = () => {
    // base steer is 0.052, each tier adds +0.007
    return 0.052 + upgrades.steering * 0.007;
  };
  const getMaxCapacity = () => {
    // base cabin is 3, each tier adds +1
    return 3 + upgrades.cabin;
  };
  const getMaxLives = () => {
    // base lives is 3, each tier adds +1
    return 3 + upgrades.armor;
  };

  const ambulanceRef = useRef<Ambulance>({
    x: 940,
    y: 710,
    width: 44,
    height: 22,
    angle: -Math.PI / 2,
    speed: 0,
    maxSpeed: 6.5,
    acceleration: 0.24,
    deceleration: 0.18,
    friction: 0.065,
    steerSpeed: 0.052,
    lives: 3,
    maxLives: 3,
    invincibleTime: 0,
    carryingPatients: [],
    maxCapacity: 3,
    skin: "classic",
  });

  const patientsRef = useRef<Patient[]>([]);
  const trafficCarsRef = useRef<TrafficCar[]>([]);
  const pedestriansRef = useRef<Pedestrian[]>([]);
  const trafficLightsRef = useRef<TrafficLight[]>([]);
  const obstaclesRef = useRef<Obstacle[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const skidmarksRef = useRef<{ x1: number; y1: number; x2: number; y2: number; alpha: number; color?: string }[]>([]);
  
  const lastTimeRef = useRef<number>(0);
  const sirenFlashRef = useRef<number>(0);
  const cameraRef = useRef<Point>({ x: 400, y: 300 });

  // Hospital Delivery Zone Coordinates
  const HOSPITAL_ZONE = { x: 880, y: 640, width: 120, height: 80 };

  // Static list of Patient location names for realistic vibe
  const LOCATION_NAMES = [
    "Downtown Bank Plaza", "Central Park Fountain", "Eco Lake Picnic Lawn",
    "Harbor Cargo Terminal", "Northeast Suburb Villas", "Shopping Promenade Mall",
    "Golf Course Greens", "Eco Lake Pier", "Construction Zone Block", "Industrial Warehouse Plaza"
  ];

  // Initialize Obstacles
  const initObstacles = () => {
    const list: Obstacle[] = [];
    
    // Grid Setup: 4x4 Blocks (cols 0..3, rows 0..3)
    // Map bounds are 0..1600. Streets sit at 400, 800, 1200
    // Block bounds are row * 400 + 60, height 280

    // Row 0
    // Col 0: Park and pond
    list.push({ id: "pond_1", x: 140, y: 140, width: 120, height: 120, type: "water" });
    // Col 1: Skyscrapers
    list.push({ id: "sky_1a", x: 480, y: 80, width: 100, height: 240, type: "building" });
    list.push({ id: "sky_1b", x: 620, y: 80, width: 100, height: 240, type: "building" });
    // Col 2: Residential
    list.push({ id: "res_1a", x: 880, y: 100, width: 90, height: 90, type: "building" });
    list.push({ id: "res_1b", x: 1010, y: 100, width: 90, height: 90, type: "building" });
    list.push({ id: "res_1c", x: 880, y: 220, width: 90, height: 90, type: "building" });
    list.push({ id: "res_1d", x: 1010, y: 220, width: 90, height: 90, type: "building" });
    // Col 3: Industrial Warehouses
    list.push({ id: "ind_1a", x: 1280, y: 80, width: 110, height: 240, type: "building" });
    list.push({ id: "ind_1b", x: 1410, y: 80, width: 110, height: 240, type: "building" });

    // Row 1
    // Col 0: Suburban villas
    list.push({ id: "sub_1a", x: 80, y: 480, width: 90, height: 90, type: "building" });
    list.push({ id: "sub_1b", x: 210, y: 480, width: 90, height: 90, type: "building" });
    list.push({ id: "sub_1c", x: 80, y: 610, width: 90, height: 90, type: "building" });
    list.push({ id: "sub_1d", x: 210, y: 610, width: 90, height: 90, type: "building" });
    // Col 1: Central Park Fountain block
    list.push({ id: "park_fountain", x: 580, y: 580, width: 40, height: 40, type: "building" });
    // Col 2: Hospital Block
    list.push({ id: "hospital_building", x: 940, y: 480, width: 160, height: 130, type: "hospital" });
    // Col 3: Shopping Mall
    list.push({ id: "shopping_mall", x: 1290, y: 490, width: 220, height: 220, type: "building" });

    // Row 2
    // Col 0: Amusement Park
    list.push({ id: "tent_1", x: 80, y: 880, width: 100, height: 100, type: "building" });
    list.push({ id: "tent_2", x: 210, y: 880, width: 100, height: 100, type: "building" });
    list.push({ id: "ferris_wheel", x: 150, y: 1010, width: 100, height: 110, type: "building" });
    // Col 1: Downtown Office skyscrapers
    list.push({ id: "sky_2a", x: 480, y: 880, width: 100, height: 240, type: "building" });
    list.push({ id: "sky_2b", x: 620, y: 880, width: 100, height: 240, type: "building" });
    // Col 2: Golf Greens sand hazard (Drawn but not solid, checked via speed penalty)
    // Col 3: Lake Reservoir
    list.push({ id: "lake_main", x: 1280, y: 880, width: 240, height: 240, type: "water" });

    // Row 3
    // Col 0: Harbor Warehouses
    list.push({ id: "dock_1", x: 80, y: 1280, width: 100, height: 240, type: "building" });
    list.push({ id: "dock_2", x: 210, y: 1280, width: 100, height: 240, type: "building" });
    // Col 1: Construction Complex
    list.push({ id: "construction_fence", x: 480, y: 1280, width: 240, height: 240, type: "building" });
    // Col 2: Pine Forest
    // Col 3: Electrical Power Grid
    list.push({ id: "power_grid", x: 1280, y: 1280, width: 240, height: 240, type: "building" });

    // Add street light poles to obstacles
    const streetLights = [
      { x: 340, y: 340 }, { x: 460, y: 340 }, { x: 340, y: 460 }, { x: 460, y: 460 },
      { x: 740, y: 340 }, { x: 860, y: 340 }, { x: 740, y: 460 }, { x: 860, y: 460 },
      { x: 1140, y: 340 }, { x: 1260, y: 340 }, { x: 1140, y: 460 }, { x: 1260, y: 460 },
      { x: 340, y: 740 }, { x: 460, y: 740 }, { x: 340, y: 860 }, { x: 460, y: 860 },
      { x: 740, y: 740 }, { x: 860, y: 740 }, { x: 740, y: 860 }, { x: 860, y: 860 },
      { x: 1140, y: 740 }, { x: 1260, y: 740 }, { x: 1140, y: 860 }, { x: 1260, y: 860 },
    ];
    streetLights.forEach((sl, index) => {
      list.push({
        id: `streetlight_${index}`,
        x: sl.x,
        y: sl.y,
        width: 12,
        height: 12,
        type: "streetlight",
      });
    });

    obstaclesRef.current = list;
  };

  // Initialize Traffic Light Controllers at major intersections
  const initTrafficLights = () => {
    const list: TrafficLight[] = [
      { id: "tl_400_400", x: 400, y: 400, state: "green", timer: 4.0 },
      { id: "tl_800_400", x: 800, y: 400, state: "red", timer: 3.5 },
      { id: "tl_1200_400", x: 1200, y: 400, state: "green", timer: 5.0 },
      { id: "tl_400_800", x: 400, y: 800, state: "red", timer: 3.0 },
      { id: "tl_800_800", x: 800, y: 800, state: "green", timer: 4.5 },
      { id: "tl_1200_800", x: 1200, y: 800, state: "red", timer: 3.8 },
      { id: "tl_400_1200", x: 400, y: 1200, state: "green", timer: 4.2 },
      { id: "tl_800_1200", x: 800, y: 1200, state: "red", timer: 3.0 },
      { id: "tl_1200_1200", x: 1200, y: 1200, state: "green", timer: 4.8 },
    ];
    trafficLightsRef.current = list;
  };

  // Initialize Pedestrians AI walking along sidewalks
  const initPedestrians = () => {
    const list: Pedestrian[] = [];
    const walkPaths = [
      { startX: 360, startY: 80, endX: 360, endY: 340 },
      { startX: 440, startY: 80, endX: 440, endY: 340 },
      { startX: 80, startY: 360, endX: 340, endY: 360 },
      { startX: 80, startY: 440, endX: 340, endY: 440 },
      { startX: 760, startY: 480, endX: 760, endY: 720 },
      { startX: 840, startY: 480, endX: 840, endY: 720 },
      { startX: 1160, startY: 840, endX: 1160, endY: 1120 },
      { startX: 1240, startY: 840, endX: 1240, endY: 1120 },
    ];

    const pedColors = ["#f87171", "#60a5fa", "#34d399", "#fbbf24", "#c084fc", "#f472b6", "#a7f3d0", "#e2e8f0"];

    for (let i = 0; i < 15; i++) {
      const path = walkPaths[Math.floor(Math.random() * walkPaths.length)];
      // Interpolate starting point
      const ratio = Math.random();
      const x = path.startX + (path.endX - path.startX) * ratio;
      const y = path.startY + (path.endY - path.startY) * ratio;

      list.push({
        id: `ped_${i}_${Date.now()}`,
        x,
        y,
        vx: 0,
        vy: 0,
        color: pedColors[Math.floor(Math.random() * pedColors.length)],
        angle: Math.random() * Math.PI * 2,
        targetX: Math.random() < 0.5 ? path.startX : path.endX,
        targetY: Math.random() < 0.5 ? path.startY : path.endY,
      });
    }
    pedestriansRef.current = list;
  };

  // Generate traffic cars
  const initTraffic = () => {
    // Determine traffic density based on difficulty
    let densityCount = 12;
    let baseSpeedMultiplier = 1.0;
    if (difficulty === "easy") {
      densityCount = 8;
      baseSpeedMultiplier = 0.8;
    } else if (difficulty === "hard") {
      densityCount = 18;
      baseSpeedMultiplier = 1.35;
    }

    const laneConfigs = [
      // Vertical highways
      { id: "car_v1", x: 380, y: 100, angle: Math.PI / 2, speed: 2.0, direction: "down", lane: 380 },
      { id: "car_v2", x: 420, y: 1500, angle: -Math.PI / 2, speed: 2.2, direction: "up", lane: 420 },
      { id: "car_v3", x: 780, y: 200, angle: Math.PI / 2, speed: 1.8, direction: "down", lane: 780 },
      { id: "car_v4", x: 820, y: 1300, angle: -Math.PI / 2, speed: 2.0, direction: "up", lane: 820 },
      { id: "car_v5", x: 1180, y: 400, angle: Math.PI / 2, speed: 2.1, direction: "down", lane: 1180 },
      { id: "car_v6", x: 1220, y: 1200, angle: -Math.PI / 2, speed: 1.9, direction: "up", lane: 1220 },
      
      // Horizontal highways
      { id: "car_h1", x: 200, y: 380, angle: Math.PI, speed: 2.1, direction: "left", lane: 380 },
      { id: "car_h2", x: 1400, y: 420, angle: 0, speed: 1.9, direction: "right", lane: 420 },
      { id: "car_h3", x: 100, y: 780, angle: Math.PI, speed: 2.2, direction: "left", lane: 780 },
      { id: "car_h4", x: 1500, y: 820, angle: 0, speed: 2.3, direction: "right", lane: 820 },
      { id: "car_h5", x: 300, y: 1180, angle: Math.PI, speed: 1.8, direction: "left", lane: 1180 },
      { id: "car_h6", x: 1300, y: 1220, angle: 0, speed: 2.0, direction: "right", lane: 1220 },
    ];

    const carColors = ["#ef4444", "#3b82f6", "#f59e0b", "#8b5cf6", "#10b981", "#f97316", "#475569", "#ec4899", "#14b8a6"];

    const list: TrafficCar[] = [];
    for (let i = 0; i < densityCount; i++) {
      const config = laneConfigs[i % laneConfigs.length];
      // Randomize offset along road length to scatter cars nicely
      const distanceOffset = Math.random() * 1200;
      let spawnedX = config.x;
      let spawnedY = config.y;

      if (config.direction === "left" || config.direction === "right") {
        spawnedX = (config.x + distanceOffset) % MAP_WIDTH;
      } else {
        spawnedY = (config.y + distanceOffset) % MAP_HEIGHT;
      }

      list.push({
        id: `car_${i}_${Date.now()}`,
        x: spawnedX,
        y: spawnedY,
        width: 32,
        height: 16,
        angle: config.angle,
        speed: config.speed * baseSpeedMultiplier,
        targetSpeed: config.speed * baseSpeedMultiplier,
        color: carColors[Math.floor(Math.random() * carColors.length)],
        direction: config.direction as any,
        lane: config.lane,
        braking: false,
      });
    }

    trafficCarsRef.current = list;
  };

  // Get terrain type at coordinate to affect physics speed and tire tracks
  const getTerrainAt = (x: number, y: number): "road" | "grass" | "sand" | "water" => {
    // Golf Course sand traps (inside Block (2, 2) which is Col 2, Row 2: 860..1140, 860..1140)
    if (x >= 900 && x <= 1010 && y >= 910 && y <= 1010) {
      return "sand";
    }

    // Lake Reservoir Block Col 3, Row 2 (1280..1520, 880..1120) and Pond (140..260, 140..260)
    if (
      (x >= 1280 && x <= 1520 && y >= 880 && y <= 1120) ||
      (x >= 140 && x <= 260 && y >= 140 && y <= 260)
    ) {
      return "water";
    }
    
    // Check if within grass blocks
    const checkGrassBlock = (bx: number, by: number) => {
      return x >= bx && x <= bx + 280 && y >= by && y <= by + 280;
    };
    
    // Park blocks
    if (
      checkGrassBlock(60, 60) ||    // Row 0, Col 0
      checkGrassBlock(460, 460) ||  // Row 1, Col 1
      checkGrassBlock(860, 860) ||  // Row 2, Col 2
      checkGrassBlock(860, 1260)    // Row 3, Col 2
    ) {
      return "grass";
    }
    
    return "road"; // default is asphalt road/sidewalk plaza
  };

  // Validate patient spawn to ensure they don't spawn inside deep water or solid building walls
  const isSpawnLocationValid = (x: number, y: number): boolean => {
    if (x < 60 || x > 1540 || y < 60 || y > 1540) return false;
    
    // No spawning in water, sand, or roads (keep them on sidewalks or grass lawns for safety)
    const terrain = getTerrainAt(x, y);
    if (terrain === "water" || terrain === "sand") return false;

    // Can't spawn inside a solid obstacle building
    for (const obs of obstaclesRef.current) {
      if (
        x >= obs.x - 18 && 
        x <= obs.x + obs.width + 18 && 
        y >= obs.y - 18 && 
        y <= obs.y + obs.height + 18
      ) {
        return false;
      }
    }
    
    // No spawning in active hospital delivery zones
    if (x >= HOSPITAL_ZONE.x - 20 && x <= HOSPITAL_ZONE.x + HOSPITAL_ZONE.width + 20 &&
        y >= HOSPITAL_ZONE.y - 20 && y <= HOSPITAL_ZONE.y + HOSPITAL_ZONE.height + 20) {
      return false;
    }
    
    return true;
  };

  // Spawn dynamic patient
  const spawnPatient = (id: string): Patient => {
    const names = [
      "Officer Dan", "Chef Lorenzo", "Professor Mia", "Librarian Clara", 
      "Dr. Carter", "Firefighter Ken", "Acrobat Sally", "Artist Leo", 
      "Gardener Rose", "Aunt Judy", "Farmer Vance", "Guitarist Jax",
      "Captain Rex", "Cousin Timmy", "Director Sarah", "Mayor Sterling"
    ];
    const severities: ("mild" | "moderate" | "severe")[] = ["mild", "moderate", "severe"];
    
    let x = 0;
    let y = 0;
    let valid = false;
    let attempts = 0;

    while (!valid && attempts < 150) {
      attempts++;
      // Choose random cell blocks (0..3)
      const gridCol = Math.floor(Math.random() * 4);
      const gridRow = Math.floor(Math.random() * 4);
      
      // Keep inside block offset (60..340 within block)
      const offsetX = 70 + Math.random() * 260;
      const offsetY = 70 + Math.random() * 260;
      
      x = gridCol * 400 + offsetX;
      y = gridRow * 400 + offsetY;
      
      if (isSpawnLocationValid(x, y)) {
        valid = true;
      }
    }

    if (!valid) {
      // Fallback safe spot in Central Green Park lawn (Col 1, Row 1)
      x = 550 + Math.random() * 120;
      y = 550 + Math.random() * 120;
    }

    const severity = severities[Math.floor(Math.random() * severities.length)];
    // Base health decay: mild is slow, severe is very fast and critical!
    const baseHealth = 100;

    return {
      id,
      x,
      y,
      name: names[Math.floor(Math.random() * names.length)],
      severity,
      pickedUp: false,
      sosPulse: Math.random() * Math.PI,
      health: baseHealth,
      maxHealth: baseHealth,
      locationName: LOCATION_NAMES[Math.floor(Math.random() * LOCATION_NAMES.length)],
    };
  };

  const initPatients = () => {
    const list: Patient[] = [];
    for (let i = 0; i < 3; i++) {
      list.push(spawnPatient(`patient_${Date.now()}_initial_${i}`));
    }
    patientsRef.current = list;
  };

  // Window Resize Observer setup
  useEffect(() => {
    if (!containerRef.current) return;
    
    const handleResize = (entries: ResizeObserverEntry[]) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setDimensions({
          width: Math.max(width, 320),
          height: Math.max(height, 280),
        });
      }
    };
    
    const observer = new ResizeObserver((entries) => {
      window.requestAnimationFrame(() => handleResize(entries));
    });
    
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      keys.current[key] = true;
      
      // Auto unlock/resume AudioContext
      soundManager.startSiren();
      soundManager.startEngine();
      soundManager.toggleSiren(!isMuted);

      // Interactive Siren Tone Cycle Controls (Q, E, or C)
      if (key === "q" || key === "e" || key === "c") {
        const modes: ("wail" | "yelp" | "phaser" | "hilo")[] = ["wail", "yelp", "phaser", "hilo"];
        const currentIdx = modes.indexOf(sirenMode);
        let nextIdx = currentIdx;
        if (key === "q") {
          nextIdx = (currentIdx - 1 + 4) % 4;
        } else {
          nextIdx = (currentIdx + 1) % 4;
        }
        onSirenModeChange(modes[nextIdx]);
        soundManager.playPickup(); // play confirmation chirp
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      keys.current[key] = false;
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [isMuted, sirenMode, onSirenModeChange]);

  // Restart, Level, Skin, or Upgrade sync resets
  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      initObstacles();
      initTrafficLights();
      initPedestrians();
      initTraffic();
      initPatients();
      
      // Configure ambulance stats with current upgrades and active skin
      ambulanceRef.current = {
        x: 940,
        y: 710,
        width: 44,
        height: 22,
        angle: -Math.PI / 2,
        speed: 0,
        maxSpeed: getMaxSpeed(),
        acceleration: 0.24,
        deceleration: 0.18,
        friction: 0.065,
        steerSpeed: getSteerSpeed(),
        lives: getMaxLives(),
        maxLives: getMaxLives(),
        invincibleTime: 0,
        carryingPatients: [],
        maxCapacity: getMaxCapacity(),
        skin: activeSkin,
      };
      
      // React state update sync
      onLivesChange(getMaxLives());
      onPatientCountChange(0);

      particlesRef.current = [];
      skidmarksRef.current = [];
      lastTimeRef.current = performance.now();
      screenShakeRef.current = 0;

      soundManager.setMute(isMuted);
      soundManager.toggleSiren(!isMuted);
      soundManager.startEngine();
      soundManager.updateEnginePitch(0);

      setHudMessage(`Level ${currentLevel} Dispatch: Save 10 patients! Speedometer Active.`);
    } else {
      soundManager.stopSiren();
      soundManager.stopEngine();
    }

    return () => {
      soundManager.stopSiren();
      soundManager.stopEngine();
    };
  }, [gameState, activeSkin, upgrades, currentLevel, difficulty]);

  // Mute toggle sync
  useEffect(() => {
    soundManager.setMute(isMuted);
  }, [isMuted]);

  // Collisions helpers
  const checkCircularCollision = (amb: Ambulance, targetX: number, targetY: number, radius: number): boolean => {
    const ambRadius = 15; // Tight circular approximation prevents rotation stickiness
    const dx = amb.x - targetX;
    const dy = amb.y - targetY;
    const distSq = dx * dx + dy * dy;
    const minDist = ambRadius + radius;
    return distSq < minDist * minDist;
  };

  const checkBuildingCollision = (amb: Ambulance, rect: Rect): boolean => {
    const ambRadius = 13;
    // Closest point on building rect
    const cx = Math.max(rect.x, Math.min(amb.x, rect.x + rect.width));
    const cy = Math.max(rect.y, Math.min(amb.y, rect.y + rect.height));
    const dx = amb.x - cx;
    const dy = amb.y - cy;
    return (dx * dx + dy * dy) < ambRadius * ambRadius;
  };

  const spawnParticles = (x: number, y: number, color: string, type: Particle["type"], count = 5) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 2.5 + 1;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: Math.random() * 4 + (type === "siren_red" || type === "siren_blue" ? 6 : 2),
        life: 1.0,
        decay: Math.random() * 0.045 + 0.02,
        type,
      });
    }
  };

  // Trigger game animation loop
  useEffect(() => {
    if (gameState !== GameState.PLAYING) {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const gameLoop = (time: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = time;
      const dt = (time - lastTimeRef.current) / 1000;
      lastTimeRef.current = time;

      const amb = ambulanceRef.current;

      // 1. DYNAMIC CONTROLS & PHYSICS Engine
      const terrain = getTerrainAt(amb.x, amb.y);
      let speedLimit = getMaxSpeed();
      let terrainFriction = amb.friction;
      let terrainAccel = amb.acceleration;

      if (terrain === "grass") {
        speedLimit *= 0.5; // Grass slows down
        terrainFriction *= 2.0;
        terrainAccel *= 0.6;
      } else if (terrain === "sand") {
        speedLimit *= 0.28; // Deep sand slows heavily
        terrainFriction *= 4.2;
        terrainAccel *= 0.3;
      } else if (terrain === "water") {
        speedLimit *= 0.15; // Water almost stalls the vehicle!
        terrainFriction *= 6.0;
        terrainAccel *= 0.15;
      }

      // Check keyboard inputs for driving
      const isDriveForward = keys.current["w"] || keys.current["arrowup"];
      const isBrakeReverse = keys.current["s"] || keys.current["arrowdown"];
      const isSteerLeft = keys.current["a"] || keys.current["arrowleft"];
      const isSteerRight = keys.current["d"] || keys.current["arrowright"];

      if (isDriveForward) {
        if (amb.speed < speedLimit) {
          amb.speed += terrainAccel;
        } else {
          amb.speed -= terrainFriction;
        }
      } else if (isBrakeReverse) {
        if (amb.speed > -speedLimit * 0.5) {
          amb.speed -= terrainAccel * 1.35; // strong deceleration & responsive reverse
        }
      } else {
        // Coasting deceleration/friction drag
        if (amb.speed > 0) {
          amb.speed = Math.max(0, amb.speed - terrainFriction);
        } else if (amb.speed < 0) {
          amb.speed = Math.min(0, amb.speed + terrainFriction);
        }
      }

      // Realistic Steering (only functional when vehicle has some speed, preventing static rotating)
      if (Math.abs(amb.speed) > 0.18) {
        // Reverse direction invert
        const reverseMultiplier = amb.speed > 0 ? 1 : -1;
        // Limit steering effectiveness slightly at extreme speeds to mimic traction loss
        const currentRatio = Math.min(Math.abs(amb.speed) / getMaxSpeed(), 1);
        const dynamicSteer = getSteerSpeed() * reverseMultiplier * (currentRatio * 0.6 + 0.4);

        if (isSteerLeft) {
          amb.angle -= dynamicSteer;
        }
        if (isSteerRight) {
          amb.angle += dynamicSteer;
        }
      }

      // Calculate previous coordinates for physics collision backup
      const prevX = amb.x;
      const prevY = amb.y;

      // Move ambulance
      amb.x += Math.cos(amb.angle) * amb.speed;
      amb.y += Math.sin(amb.angle) * amb.speed;

      // Update Engine pitching sound
      const speedRatio = Math.min(Math.abs(amb.speed) / getMaxSpeed(), 1);
      soundManager.updateEnginePitch(speedRatio);
      soundManager.updateSirenPitch(speedRatio);

      // Convert speed to KM/H for UI Speedometer
      const speedKmh = Math.round(Math.abs(amb.speed) * 22);
      setCurrentSpeedKmh(speedKmh);

      // Map boundary collisions
      const boundBuf = 16;
      if (amb.x < boundBuf) { amb.x = boundBuf; amb.speed = -amb.speed * 0.3; screenShakeRef.current = 6; }
      if (amb.x > MAP_WIDTH - boundBuf) { amb.x = MAP_WIDTH - boundBuf; amb.speed = -amb.speed * 0.3; screenShakeRef.current = 6; }
      if (amb.y < boundBuf) { amb.y = boundBuf; amb.speed = -amb.speed * 0.3; screenShakeRef.current = 6; }
      if (amb.y > MAP_HEIGHT - boundBuf) { amb.y = MAP_HEIGHT - boundBuf; amb.speed = -amb.speed * 0.3; screenShakeRef.current = 6; }

      // 2. INTERSECTION TRAFFIC LIGHT SYSTEMS Cycle
      trafficLightsRef.current.forEach((tl) => {
        tl.timer -= dt;
        if (tl.timer <= 0) {
          if (tl.state === "green") {
            tl.state = "yellow";
            tl.timer = 1.5;
          } else if (tl.state === "yellow") {
            tl.state = "red";
            tl.timer = 4.0;
          } else {
            tl.state = "green";
            tl.timer = 4.0;
          }
        }
      });

      // 3. STATIC BUILDING / OBSTACLES COLLISIONS
      let didHitObstacle = false;
      for (const obs of obstaclesRef.current) {
        if (checkBuildingCollision(amb, obs)) {
          didHitObstacle = true;
          // Physics rollback
          amb.x = prevX;
          amb.y = prevY;

          if (Math.abs(amb.speed) > 1.8) {
            // Apply crash penalty if not invincible
            if (amb.invincibleTime <= 0) {
              const damageLives = lives - 1;
              onLivesChange(damageLives);
              amb.lives = damageLives;
              amb.invincibleTime = 90; // 1.5s invincibility frames
              screenShakeRef.current = 14;

              soundManager.playCrash();
              spawnParticles(amb.x, amb.y, "#f59e0b", "spark", 15);
              spawnParticles(amb.x, amb.y, "#64748b", "smoke", 12);

              setHudMessage("Ouch! Speed Collision! -1 Ambulance health.");
              setTimeout(() => setHudMessage(null), 2500);
            }
            amb.speed = -amb.speed * 0.35; // bounce backwards
          } else {
            amb.speed = 0;
          }
          break;
        }
      }

      // Countdown invincibility frames
      if (amb.invincibleTime > 0) {
        amb.invincibleTime--;
      }

      // Tire tracks & smoke generation on sharp turn drifts
      if (Math.abs(amb.speed) > 2.2) {
        const isTurning = isSteerLeft || isSteerRight;
        if (isTurning || terrain === "grass" || terrain === "sand") {
          const wCos = Math.cos(amb.angle);
          const wSin = Math.sin(amb.angle);
          
          // Wheel offsets
          const wheelX1 = amb.x - wCos * 15 + wSin * 8;
          const wheelY1 = amb.y - wSin * 15 - wCos * 8;
          const wheelX2 = amb.x - wCos * 15 - wSin * 8;
          const wheelY2 = amb.y - wSin * 15 + wCos * 8;

          const trackCol = terrain === "grass" ? "#166534" : (terrain === "sand" ? "#ca8a04" : "rgba(15,23,42,0.65)");

          skidmarksRef.current.push({ x1: wheelX1, y1: wheelY1, x2: wheelX1 - wCos * amb.speed * 1.5, y2: wheelY1 - wSin * amb.speed * 1.5, alpha: 0.5, color: trackCol });
          skidmarksRef.current.push({ x1: wheelX2, y1: wheelY2, x2: wheelX2 - wCos * amb.speed * 1.5, y2: wheelY2 - wSin * amb.speed * 1.5, alpha: 0.5, color: trackCol });

          if (skidmarksRef.current.length > 350) {
            skidmarksRef.current.shift();
            skidmarksRef.current.shift();
          }

          // Spawn smoke particles
          if (Math.random() < 0.28) {
            const smokeCol = terrain === "sand" ? "#fef08a" : (terrain === "grass" ? "#22c55e" : "#cbd5e1");
            particlesRef.current.push({
              x: wheelX1,
              y: wheelY1,
              vx: -wCos * 2.2 + (Math.random() - 0.5),
              vy: -wSin * 2.2 + (Math.random() - 0.5),
              color: smokeCol,
              size: Math.random() * 3.5 + 2,
              life: 1.0,
              decay: 0.035,
              type: "smoke"
            });
          }
        }
      }

      // 4. TRAFFIC CARS AI & COLLISIONS
      trafficCarsRef.current.forEach((car) => {
        // Identify traffic light control at this lane intersection
        let speedMult = 1.0;
        let shouldStop = false;

        // Intersection collision bounds
        trafficLightsRef.current.forEach((tl) => {
          if (tl.state === "red") {
            const distToLight = Math.sqrt((car.x - tl.x) * (car.x - tl.x) + (car.y - tl.y) * (car.y - tl.y));
            if (distToLight < 120) {
              // Only stop if heading into the intersection line
              if (car.direction === "down" && car.y < tl.y - 30 && car.y > tl.y - 100) shouldStop = true;
              if (car.direction === "up" && car.y > tl.y + 30 && car.y < tl.y + 100) shouldStop = true;
              if (car.direction === "right" && car.x < tl.x - 30 && car.x > tl.x - 100) shouldStop = true;
              if (car.direction === "left" && car.x > tl.x + 30 && car.x < tl.x + 100) shouldStop = true;
            }
          }
        });

        // Smart braking AI: Yield or slow down if ambulance sirens are extremely close by!
        const dxToAmb = amb.x - car.x;
        const dyToAmb = amb.y - car.y;
        const distToAmb = Math.sqrt(dxToAmb * dxToAmb + dyToAmb * dyToAmb);
        let pullAwayX = 0;
        let pullAwayY = 0;

        if (distToAmb < 130) {
          speedMult = 0.45; // brake heavily
          car.braking = true;

          // Attempt to slightly dodge the ambulance by pulling onto roadside margins
          if (car.direction === "down" || car.direction === "up") {
            pullAwayX = dxToAmb > 0 ? -1.0 : 1.0; // drift away horizontally
          } else {
            pullAwayY = dyToAmb > 0 ? -1.0 : 1.0; // drift away vertically
          }
        } else {
          car.braking = false;
        }

        if (shouldStop) {
          car.speed = Math.max(0, car.speed - 0.22); // smoothly decelerate to halt
          car.braking = true;
        } else {
          // Accelerate back to target traffic speed
          const limit = car.targetSpeed * speedMult;
          if (car.speed < limit) {
            car.speed += 0.12;
          } else if (car.speed > limit) {
            car.speed = Math.max(limit, car.speed - 0.18);
          }
        }

        // Apply velocities
        if (car.direction === "left") {
          car.x -= car.speed;
          car.y += pullAwayY;
          car.angle = Math.PI;
          if (car.x < -30) car.x = MAP_WIDTH + 30;
        } else if (car.direction === "right") {
          car.x += car.speed;
          car.y += pullAwayY;
          car.angle = 0;
          if (car.x > MAP_WIDTH + 30) car.x = -30;
        } else if (car.direction === "up") {
          car.y -= car.speed;
          car.x += pullAwayX;
          car.angle = -Math.PI / 2;
          if (car.y < -30) car.y = MAP_HEIGHT + 30;
        } else if (car.direction === "down") {
          car.y += car.speed;
          car.x += pullAwayX;
          car.angle = Math.PI / 2;
          if (car.y > MAP_HEIGHT + 30) car.y = -30;
        }

        // Traffic vs Ambulance Crash Checking
        if (checkCircularCollision(amb, car.x, car.y, 16)) {
          if (amb.invincibleTime <= 0) {
            const damageLives = lives - 1;
            onLivesChange(damageLives);
            amb.lives = damageLives;
            amb.invincibleTime = 90;
            screenShakeRef.current = 15;

            soundManager.playCrash();
            spawnParticles(amb.x, amb.y, "#ef4444", "spark", 15);
            spawnParticles(amb.x, amb.y, "#475569", "smoke", 10);

            // Crash pushback physics
            const collisionAngle = Math.atan2(amb.y - car.y, amb.x - car.x);
            amb.x += Math.cos(collisionAngle) * 22;
            amb.y += Math.sin(collisionAngle) * 22;
            amb.speed = -amb.speed * 0.45; // bounce backward

            // Traffic car spins out/stalls briefly
            car.speed = -0.5;

            setHudMessage("Traffic Collision! -1 Health unit. Watch the lanes!");
            setTimeout(() => setHudMessage(null), 2500);
          }
        }
      });

      // 5. PEDESTRIAN AI LOGIC
      pedestriansRef.current.forEach((ped) => {
        // Move towards target point
        const dx = ped.targetX - ped.x;
        const dy = ped.targetY - ped.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < 15) {
          // Pick new target point nearby on sidewalk
          const isHorizontalSidewalk = Math.random() < 0.5;
          if (isHorizontalSidewalk) {
            ped.targetX = 100 + Math.random() * 1400;
          } else {
            ped.targetY = 100 + Math.random() * 1400;
          }
        } else {
          ped.vx = (dx / distance) * 0.95; // walking pace
          ped.vy = (dy / distance) * 0.95;
          ped.angle = Math.atan2(ped.vy, ped.vx);

          // Dodge incoming ambulance! (Dive out of danger with high velocity!)
          const dxToAmb = amb.x - ped.x;
          const dyToAmb = amb.y - ped.y;
          const distToAmb = Math.sqrt(dxToAmb * dxToAmb + dyToAmb * dyToAmb);
          if (distToAmb < 70) {
            // Dive perpendicular/away from ambulance vector
            const dodgeAngle = Math.atan2(ped.y - amb.y, ped.x - amb.x);
            ped.vx = Math.cos(dodgeAngle) * 3.8; // jump dive speed!
            ped.vy = Math.sin(dodgeAngle) * 3.8;
            ped.angle = dodgeAngle;

            // Spawn sweat/alert drops
            if (Math.random() < 0.15) {
              spawnParticles(ped.x, ped.y, "#60a5fa", "smoke", 2);
            }
          }

          ped.x += ped.vx;
          ped.y += ped.vy;
        }

        // Keep inside bounds
        ped.x = Math.max(40, Math.min(MAP_WIDTH - 40, ped.x));
        ped.y = Math.max(40, Math.min(MAP_HEIGHT - 40, ped.y));

        // Friendly collision nudge (avoid crushing pedestrians, make them yell)
        if (checkCircularCollision(amb, ped.x, ped.y, 10)) {
          // Push pedestrian away
          const pushAngle = Math.atan2(ped.y - amb.y, ped.x - amb.x);
          ped.x += Math.cos(pushAngle) * 20;
          ped.y += Math.sin(pushAngle) * 20;
          
          spawnParticles(ped.x, ped.y, "#fbbf24", "spark", 3);
          
          setHudMessage("Yikes! Watch the sidewalks! Pedestrian dodged!");
          setTimeout(() => setHudMessage(null), 1500);
        }
      });

      // 6. PATIENT REGENERATION, HEALTH DECAY, BOARDING
      // Patient Health decays on map over time!
      patientsRef.current.forEach((patient) => {
        if (!patient.pickedUp) {
          // Decays based on severity: severe is extremely critical!
          let decayRate = 0.9; // 0.9% health lost per second
          if (patient.severity === "moderate") decayRate = 1.6;
          if (patient.severity === "severe") decayRate = 2.45;

          patient.health = Math.max(0, patient.health - decayRate * dt * 10);

          // If health reaches 0, they expire and respawn elsewhere
          if (patient.health <= 0) {
            spawnParticles(patient.x, patient.y, "#64748b", "smoke", 18);
            
            setHudMessage(`Urgent: Patient ${patient.name} expired before pickup!`);
            setTimeout(() => setHudMessage(null), 3000);

            // Replace them
            patient.pickedUp = true; // flag to filter
          }
        }
      });

      // Handle cabin patient health decay as well!
      // Carrying patients must be rushed to the hospital dock before they expire!
      amb.carryingPatients.forEach((patient, idx) => {
        let decayRate = 0.55; // slower inside ambulance because of emergency cabin life-support!
        if (patient.severity === "moderate") decayRate = 0.95;
        if (patient.severity === "severe") decayRate = 1.65;

        patient.health = Math.max(0, patient.health - decayRate * dt * 10);

        if (patient.health <= 0) {
          // Boarded patient expired in cabin!
          spawnParticles(amb.x, amb.y, "#94a3b8", "smoke", 15);
          setHudMessage(`Tragic: Patient ${patient.name} expired in the cabin!`);
          setTimeout(() => setHudMessage(null), 3500);

          // Remove expired patient
          amb.carryingPatients.splice(idx, 1);
          onPatientCountChange(amb.carryingPatients.length);
        }
      });

      // Filter out picking up / expired patients
      const remainingPatients = patientsRef.current.filter((p) => !p.pickedUp && p.health > 0);
      if (remainingPatients.length < 3) {
        const needed = 3 - remainingPatients.length;
        for (let i = 0; i < needed; i++) {
          remainingPatients.push(spawnPatient(`patient_${Date.now()}_ref_${Math.random()}`));
        }
      }
      patientsRef.current = remainingPatients;

      // Boarding checking
      const pickupRadius = 38;
      patientsRef.current.forEach((patient) => {
        if (!patient.pickedUp && patient.health > 0) {
          const distanceToAmb = Math.sqrt((amb.x - patient.x) * (amb.x - patient.x) + (amb.y - patient.y) * (amb.y - patient.y));
          if (distanceToAmb < pickupRadius) {
            // Check capacity limit
            if (amb.carryingPatients.length < getMaxCapacity()) {
              patient.pickedUp = true;
              amb.carryingPatients.push({ ...patient }); // push copy with current decaying health
              onPatientCountChange(amb.carryingPatients.length);

              soundManager.playPickup();
              spawnParticles(patient.x, patient.y, "#10b981", "plus", 10);
              spawnParticles(patient.x, patient.y, "#ef4444", "heart", 6);

              // Small score reward for picking up
              onScoreChange(score + 40);

              setHudMessage(`Patient boarded: ${patient.name}! Severity: ${patient.severity.toUpperCase()}. Rush to Hospital!`);
              setTimeout(() => setHudMessage(null), 3000);
            } else {
              setHudMessage("Ambulance Full! Deliver current patients to City Hospital first.");
              setTimeout(() => setHudMessage(null), 2000);
            }
          }
        }
      });

      // 7. HOSPITAL DELIVERY LOGIC
      // Hospital parking dock zone collision bounds
      const inHospitalDock = (
        amb.x >= HOSPITAL_ZONE.x && 
        amb.x <= HOSPITAL_ZONE.x + HOSPITAL_ZONE.width && 
        amb.y >= HOSPITAL_ZONE.y && 
        amb.y <= HOSPITAL_ZONE.y + HOSPITAL_ZONE.height
      );

      if (inHospitalDock && amb.carryingPatients.length > 0) {
        const countDelivered = amb.carryingPatients.length;
        let scoreReward = 0;
        let timeBonus = 0;
        let coinsReward = 0;
        let xpReward = 0;

        amb.carryingPatients.forEach((patient) => {
          // Score and coin reward scales by patient severity and health remaining!
          let severityMult = 1.0;
          let baseReward = 100;
          let addedSec = 16;
          let baseCoins = 25;
          let baseXp = 40;

          if (patient.severity === "moderate") {
            severityMult = 1.5;
            baseReward = 150;
            addedSec = 22;
            baseCoins = 40;
            baseXp = 65;
          } else if (patient.severity === "severe") {
            severityMult = 2.2;
            baseReward = 220;
            addedSec = 28;
            baseCoins = 60;
            baseXp = 100;
          }

          // Bonus multipliers for fast response (keeping patient health high!)
          const healthBonusFactor = 0.5 + (patient.health / 100) * 0.5; // up to 1.0x

          scoreReward += Math.round(baseReward * healthBonusFactor);
          coinsReward += Math.round(baseCoins * healthBonusFactor);
          xpReward += Math.round(baseXp * healthBonusFactor);
          timeBonus += Math.round(addedSec * healthBonusFactor);
        });

        // Apply awards
        const nextRescuedCount = patientsRescued + countDelivered;
        onPatientsRescued(nextRescuedCount);
        onScoreChange(score + scoreReward);
        onAddCoins(coinsReward);
        onAddXp(xpReward);

        // Add to timer countdown (capped at 99s)
        onTimerChange(Math.min(timer + timeBonus, 99));

        soundManager.playDelivery();
        spawnParticles(amb.x, amb.y - 10, "#3b82f6", "plus", 14);
        spawnParticles(amb.x, amb.y + 10, "#10b981", "heart", 18);

        // Clear cabin patients
        amb.carryingPatients = [];
        onPatientCountChange(0);

        setHudMessage(`SAVED: Delivered ${countDelivered} Patients! +${scoreReward} PTS, +${coinsReward} Coins, +${timeBonus}s!`);
        setTimeout(() => setHudMessage(null), 4000);

        // Check level win progression
        if (nextRescuedCount >= 10) {
          onGameStateChange(GameState.WIN);
          soundManager.playWin();
          soundManager.stopEngine();
        }
      }

      // Check failure parameters
      if (amb.lives <= 0 || timer <= 0) {
        onGameStateChange(GameState.GAME_OVER);
        soundManager.playGameOver();
        soundManager.stopEngine();
      }

      // 8. ANIMATE PARTICLES
      particlesRef.current.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= p.decay;

        // Sirens pulse glow size expansion
        if (p.type === "siren_red" || p.type === "siren_blue") {
          p.size += 0.8;
        }
      });
      particlesRef.current = particlesRef.current.filter((p) => p.life > 0);

      // Increment siren lights rotation count
      sirenFlashRef.current += 1;

      // Spawning ambient flashing siren light particles around ambulance for realism
      if (sirenFlashRef.current % 3 === 0) {
        const angleOffset = Math.random() * Math.PI * 2;
        const color = sirenFlashRef.current % 6 < 3 ? "rgba(239, 68, 68, 0.25)" : "rgba(59, 130, 246, 0.25)";
        const type = sirenFlashRef.current % 6 < 3 ? "siren_red" : "siren_blue";
        particlesRef.current.push({
          x: amb.x + Math.cos(amb.angle) * 10,
          y: amb.y + Math.sin(amb.angle) * 10,
          vx: Math.cos(angleOffset) * 0.5,
          vy: Math.sin(angleOffset) * 0.5,
          color,
          size: 14,
          life: 0.35,
          decay: 0.08,
          type,
        });
      }

      // 9. CINEMATIC CAMERA SYSTEM
      // Smooth interpolation centered on active vehicle
      const targetCamX = amb.x - dimensions.width / 2;
      const targetCamY = amb.y - dimensions.height / 2;
      
      cameraRef.current.x += (targetCamX - cameraRef.current.x) * 0.085;
      cameraRef.current.y += (targetCamY - cameraRef.current.y) * 0.085;

      // Clamp camera within map borders
      cameraRef.current.x = Math.max(0, Math.min(MAP_WIDTH - dimensions.width, cameraRef.current.x));
      cameraRef.current.y = Math.max(0, Math.min(MAP_HEIGHT - dimensions.height, cameraRef.current.y));

      // Screen shake decay
      if (screenShakeRef.current > 0) {
        screenShakeRef.current *= 0.9;
        if (screenShakeRef.current < 0.2) screenShakeRef.current = 0;
      }

      // 10. DRAW GRAPHICS & CANVAS SCENE
      const camX = cameraRef.current.x + (Math.random() - 0.5) * screenShakeRef.current;
      const camY = cameraRef.current.y + (Math.random() - 0.5) * screenShakeRef.current;

      // Base background asphalt
      ctx.fillStyle = "#0f172a"; // Clean modern slate theme
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);

      ctx.save();
      ctx.translate(-camX, -camY);

      // Draw Grid markings
      ctx.strokeStyle = "rgba(148, 163, 184, 0.03)";
      ctx.lineWidth = 1;
      for (let gx = 0; gx <= MAP_WIDTH; gx += 100) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, MAP_HEIGHT);
        ctx.stroke();
      }
      for (let gy = 0; gy <= MAP_HEIGHT; gy += 100) {
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(MAP_WIDTH, gy);
        ctx.stroke();
      }

      // Draw yellow lane centerlines on double lane highways
      const highways = [400, 800, 1200];
      ctx.strokeStyle = "#eab308"; // Beautiful highway gold
      ctx.lineWidth = 3;
      ctx.setLineDash([15, 15]);
      highways.forEach((hw) => {
        // Horizontal lanes
        ctx.beginPath();
        ctx.moveTo(15, hw);
        ctx.lineTo(MAP_WIDTH - 15, hw);
        ctx.stroke();

        // Vertical lanes
        ctx.beginPath();
        ctx.moveTo(hw, 15);
        ctx.lineTo(hw, MAP_HEIGHT - 15);
        ctx.stroke();
      });
      ctx.setLineDash([]); // reset

      // Draw sidewalk markings & white crosswalk paint lines
      ctx.fillStyle = "rgba(255,255,255,0.12)";
      const crossways = [
        { x: 400, y: 340, horiz: true }, { x: 400, y: 460, horiz: true },
        { x: 800, y: 340, horiz: true }, { x: 800, y: 460, horiz: true },
        { x: 1200, y: 340, horiz: true }, { x: 1200, y: 460, horiz: true },
        { x: 340, y: 400, horiz: false }, { x: 460, y: 400, horiz: false },
        { x: 740, y: 400, horiz: false }, { x: 860, y: 400, horiz: false },
        { x: 1140, y: 400, horiz: false }, { x: 1260, y: 400, horiz: false },
        { x: 400, y: 740, horiz: true }, { x: 400, y: 860, horiz: true },
        { x: 800, y: 740, horiz: true }, { x: 800, y: 860, horiz: true },
        { x: 1200, y: 740, horiz: true }, { x: 1200, y: 860, horiz: true },
        { x: 340, y: 800, horiz: false }, { x: 460, y: 800, horiz: false },
        { x: 740, y: 800, horiz: false }, { x: 860, y: 800, horiz: false },
        { x: 1140, y: 800, horiz: false }, { x: 1260, y: 800, horiz: false },
      ];
      crossways.forEach((cw) => {
        if (cw.horiz) {
          for (let offset = -40; offset <= 40; offset += 14) {
            ctx.fillRect(cw.x + offset, cw.y - 12, 6, 24);
          }
        } else {
          for (let offset = -40; offset <= 40; offset += 14) {
            ctx.fillRect(cw.x - 12, cw.y + offset, 24, 6);
          }
        }
      });

      // Draw block plaza fields (grass lawns vs. corporate gray concrete)
      const layoutBlocks = [
        { r: 0, c: 0, type: "park", color: "#14532d", label: "Eco Lake Park" },
        { r: 0, c: 1, type: "plaza", color: "#1e293b", label: "Downtown Square" },
        { r: 0, c: 2, type: "suburb", color: "#0f172a", label: "Northeast Suburbs" },
        { r: 0, c: 3, type: "industrial", color: "#334155", label: "Cargo Terminal" },
        { r: 1, c: 0, type: "suburb", color: "#0f172a", label: "West End Villas" },
        { r: 1, c: 1, type: "park", color: "#166534", label: "Central Green" },
        { r: 1, c: 2, type: "hospital", color: "#1e293b", label: "Hospital District" },
        { r: 1, c: 3, type: "plaza", color: "#334155", label: "Shopping Promenade" },
        { r: 2, c: 0, type: "plaza", color: "#1e293b", label: "Amusement Fair" },
        { r: 2, c: 1, type: "plaza", color: "#0f172a", label: "Finance Towers" },
        { r: 2, c: 2, type: "park", color: "#15803d", label: "Scenic Golf Greens" },
        { r: 2, c: 3, type: "park", color: "#064e3b", label: "Lagoon Reservoir" },
        { r: 3, c: 0, type: "industrial", color: "#334155", label: "Harbor Drydocks" },
        { r: 3, c: 1, type: "plaza", color: "#1e293b", label: "Under Construction" },
        { r: 3, c: 2, type: "park", color: "#14532d", label: "Pine Valley" },
        { r: 3, c: 3, type: "industrial", color: "#1e293b", label: "Power Grid Facility" },
      ];

      layoutBlocks.forEach((block) => {
        const bx = block.c * 400 + 60;
        const by = block.r * 400 + 60;

        if (block.type === "park") {
          ctx.fillStyle = "#14532d"; // dark forest green
          ctx.fillRect(bx, by, 280, 280);
          ctx.strokeStyle = "#15803d";
          ctx.lineWidth = 4;
          ctx.strokeRect(bx, by, 280, 280);
        } else if (block.type === "hospital") {
          ctx.fillStyle = "#1e293b"; // dark concrete plaza
          ctx.fillRect(bx, by, 280, 280);
          ctx.strokeStyle = "#38bdf8"; // cyan hospital grid boundary
          ctx.lineWidth = 4;
          ctx.strokeRect(bx, by, 280, 280);
        } else {
          ctx.fillStyle = "#1e293b"; // normal sidewalk concrete block
          ctx.fillRect(bx, by, 280, 280);
          ctx.strokeStyle = "#475569";
          ctx.lineWidth = 3;
          ctx.strokeRect(bx, by, 280, 280);
        }

        // Draw sidewalk curbs
        ctx.strokeStyle = "#334155";
        ctx.lineWidth = 6;
        ctx.strokeRect(bx - 3, by - 3, 286, 286);

        // Render block label for navigation realism
        ctx.fillStyle = "rgba(148, 163, 184, 0.4)";
        ctx.font = "bold 9px monospace";
        ctx.textAlign = "center";
        ctx.fillText(block.label.toUpperCase(), bx + 140, by + 18);
      });

      // Draw Golf Sand trap hazard in col 2, row 2
      ctx.fillStyle = "#fef08a"; // sand trap
      ctx.beginPath();
      ctx.roundRect(910, 920, 110, 95, [25]);
      ctx.fill();
      ctx.strokeStyle = "#ca8a04";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = "#b45309";
      ctx.font = "italic bold 9px monospace";
      ctx.fillText("SAND TRAP - SPEED PENALTY", 965, 970);

      // Draw Permanent tire skidmarks
      skidmarksRef.current.forEach((sm) => {
        ctx.strokeStyle = sm.color || `rgba(0, 0, 0, ${sm.alpha})`;
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(sm.x1, sm.y1);
        ctx.lineTo(sm.x2, sm.y2);
        ctx.stroke();
      });

      // Draw Hospital delivery platform parking bay
      ctx.save();
      ctx.fillStyle = "rgba(16, 185, 129, 0.15)"; // pulsing translucent delivery bay
      const bayPulse = Math.sin(time / 220) * 0.15 + 0.85;
      ctx.fillRect(HOSPITAL_ZONE.x, HOSPITAL_ZONE.y, HOSPITAL_ZONE.width, HOSPITAL_ZONE.height);
      
      // Translucent strobe
      ctx.strokeStyle = sirenFlashRef.current % 40 < 20 ? "#10b981" : "#ffffff";
      ctx.lineWidth = 4;
      ctx.setLineDash([8, 8]);
      ctx.strokeRect(HOSPITAL_ZONE.x, HOSPITAL_ZONE.y, HOSPITAL_ZONE.width, HOSPITAL_ZONE.height);
      ctx.setLineDash([]);

      // Draw neon green ambulance medical cross
      ctx.fillStyle = "#10b981";
      const crossX = HOSPITAL_ZONE.x + HOSPITAL_ZONE.width / 2;
      const crossY = HOSPITAL_ZONE.y + HOSPITAL_ZONE.height / 2;
      ctx.fillRect(crossX - 25, crossY - 8, 50, 16);
      ctx.fillRect(crossX - 8, crossY - 25, 16, 50);

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 9px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("HOSPITAL BAY", crossX, HOSPITAL_ZONE.y + 70);
      ctx.restore();

      // Draw City street lights casting beautiful ambient circular lit pools
      const illuminationSpots = [
        { x: 340, y: 340 }, { x: 460, y: 340 }, { x: 340, y: 460 }, { x: 460, y: 460 },
        { x: 740, y: 340 }, { x: 860, y: 340 }, { x: 740, y: 460 }, { x: 860, y: 460 },
        { x: 1140, y: 340 }, { x: 1260, y: 340 }, { x: 1140, y: 460 }, { x: 1260, y: 460 },
        { x: 340, y: 740 }, { x: 460, y: 740 }, { x: 340, y: 860 }, { x: 460, y: 860 },
        { x: 740, y: 740 }, { x: 860, y: 740 }, { x: 740, y: 860 }, { x: 860, y: 860 },
        { x: 1140, y: 740 }, { x: 1260, y: 740 }, { x: 1140, y: 860 }, { x: 1260, y: 860 },
      ];
      illuminationSpots.forEach((spot) => {
        const spotRad = 55;
        const grad = ctx.createRadialGradient(spot.x, spot.y, 5, spot.x, spot.y, spotRad);
        grad.addColorStop(0, "rgba(254, 240, 138, 0.2)");
        grad.addColorStop(1, "rgba(254, 240, 138, 0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(spot.x, spot.y, spotRad, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Obstacles (Buildings, Water structures, Street light poles)
      obstaclesRef.current.forEach((obs) => {
        if (obs.type === "water") {
          // Lake reservoirs
          ctx.fillStyle = "#0284c7"; // deep water blue
          ctx.fillRect(obs.x, obs.y, obs.width, obs.height);

          // Animate small rolling surface waves
          ctx.strokeStyle = "#38bdf8";
          ctx.lineWidth = 3;
          ctx.beginPath();
          const wave = Math.sin(time / 250) * 6;
          ctx.moveTo(obs.x, obs.y + obs.height/2 + wave);
          ctx.bezierCurveTo(
            obs.x + obs.width/3, obs.y + obs.height/2 - 12 + wave, 
            obs.x + 2*obs.width/3, obs.y + obs.height/2 + 12 + wave, 
            obs.x + obs.width, obs.y + obs.height/2 + wave
          );
          ctx.stroke();

          ctx.fillStyle = "rgba(255, 255, 255, 0.5)";
          ctx.font = "bold 11px monospace";
          ctx.textAlign = "center";
          ctx.fillText("DANGEROUS DEEP RESERVOIR", obs.x + obs.width / 2, obs.y + obs.height / 2 + 4);

          ctx.strokeStyle = "#0369a1";
          ctx.lineWidth = 4;
          ctx.strokeRect(obs.x, obs.y, obs.width, obs.height);
        } else if (obs.type === "hospital") {
          // Spectacular 3D styled medical hospital block
          ctx.fillStyle = "#64748b"; // shadow side
          ctx.fillRect(obs.x, obs.y, obs.width, obs.height);

          // Glowing roof
          ctx.fillStyle = "#f8fafc";
          ctx.fillRect(obs.x, obs.y, obs.width, obs.height - 12);

          // Medical red stripes decoration
          ctx.fillStyle = "#ef4444";
          ctx.fillRect(obs.x, obs.y + 45, obs.width, 10);

          // Red cross roof emblem
          ctx.fillStyle = "#ef4444";
          const hcx = obs.x + obs.width / 2;
          const hcy = obs.y + (obs.height - 12) / 2;
          ctx.fillRect(hcx - 25, hcy - 8, 50, 16);
          ctx.fillRect(hcx - 8, hcy - 25, 16, 50);

          ctx.fillStyle = "#0f172a";
          ctx.font = "bold 12px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("METROPOLIS GENERAL HOSPITAL", hcx, hcy + 40);
        } else if (obs.type === "streetlight") {
          // Metal pole stand shadow
          ctx.fillStyle = "rgba(0,0,0,0.45)";
          ctx.beginPath();
          ctx.arc(obs.x + 3, obs.y + 3, 5, 0, Math.PI * 2);
          ctx.fill();

          // Metal pole core
          ctx.fillStyle = "#475569";
          ctx.beginPath();
          ctx.arc(obs.x, obs.y, 4, 0, Math.PI * 2);
          ctx.fill();

          // Yellow lamp tip
          ctx.fillStyle = "#fef08a";
          ctx.beginPath();
          ctx.arc(obs.x, obs.y, 2.5, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // Standard city skyscrapers
          const bHeight = obs.id.includes("sky") ? 20 : 10;
          
          // Shadow bevel
          ctx.fillStyle = "#0f172a";
          ctx.fillRect(obs.x, obs.y, obs.width, obs.height);

          // Roof top color
          ctx.fillStyle = obs.id.includes("sky") ? "#334155" : "#475569";
          ctx.fillRect(obs.x, obs.y, obs.width, obs.height - bHeight);

          // Windows lighting on taller towers
          if (obs.id.includes("sky")) {
            ctx.fillStyle = sirenFlashRef.current % 120 < 60 ? "#fef08a" : "#ea580c";
            for (let wx = obs.x + 12; wx < obs.x + obs.width - 10; wx += 24) {
              for (let wy = obs.y + 12; wy < obs.y + obs.height - bHeight - 10; wy += 28) {
                ctx.fillRect(wx, wy, 8, 12);
              }
            }
          } else {
            // Residential gable roof outlines
            ctx.strokeStyle = "#1e293b";
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(obs.x, obs.y);
            ctx.lineTo(obs.x + obs.width / 2, obs.y + (obs.height - bHeight) / 2);
            ctx.lineTo(obs.x + obs.width, obs.y);
            ctx.stroke();
          }

          ctx.strokeStyle = "#0f172a";
          ctx.lineWidth = 3;
          ctx.strokeRect(obs.x, obs.y, obs.width, obs.height - bHeight);
        }
      });

      // Draw Lush decorative green trees
      const forestSpots = [
        { x: 100, y: 100 }, { x: 300, y: 100 }, { x: 100, y: 300 }, { x: 300, y: 300 },
        { x: 500, y: 500 }, { x: 700, y: 500 }, { x: 500, y: 700 }, { x: 700, y: 700 }, { x: 600, y: 600 },
        { x: 1100, y: 1100 }, { x: 900, y: 1100 }, { x: 1100, y: 900 }, { x: 900, y: 900 },
        { x: 1000, y: 1350 }, { x: 900, y: 1450 }, { x: 1100, y: 1450 },
        { x: 500, y: 1400 }, { x: 600, y: 1450 }, { x: 1450, y: 500 }, { x: 1400, y: 600 }
      ];
      forestSpots.forEach((tree) => {
        // Shadow
        ctx.fillStyle = "rgba(0,0,0,0.2)";
        ctx.beginPath();
        ctx.arc(tree.x + 3, tree.y + 4, 15, 0, Math.PI * 2);
        ctx.fill();

        // Trunk
        ctx.fillStyle = "#78350f";
        ctx.beginPath();
        ctx.arc(tree.x, tree.y, 4, 0, Math.PI * 2);
        ctx.fill();

        // Canopy
        ctx.fillStyle = "#166534";
        ctx.beginPath();
        ctx.arc(tree.x, tree.y - 4, 16, 0, Math.PI * 2);
        ctx.fill();

        // Highlight layer
        ctx.fillStyle = "#22c55e";
        ctx.beginPath();
        ctx.arc(tree.x - 4, tree.y - 8, 10, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Pedestrians
      pedestriansRef.current.forEach((ped) => {
        ctx.save();
        ctx.translate(ped.x, ped.y);
        ctx.rotate(ped.angle);

        // Pedestrian body circle shadow
        ctx.fillStyle = "rgba(0,0,0,0.3)";
        ctx.beginPath();
        ctx.arc(1.5, 2, 5, 0, Math.PI * 2);
        ctx.fill();

        // Colored outfit
        ctx.fillStyle = ped.color;
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();

        // Head skin node
        ctx.fillStyle = "#fecdd3";
        ctx.beginPath();
        ctx.arc(2, 0, 3, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      });

      // Draw Patients to rescue
      patientsRef.current.forEach((patient) => {
        if (patient.pickedUp || patient.health <= 0) return;

        patient.sosPulse += 0.052;
        const pulseSize = Math.sin(patient.sosPulse) * 8 + 14;

        // Pulse SOS Circle rings
        ctx.strokeStyle = "rgba(239, 68, 68, 0.35)";
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(patient.x, patient.y, pulseSize + 14, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = "rgba(255, 255, 255, 0.8)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(patient.x, patient.y, pulseSize, 0, Math.PI * 2);
        ctx.stroke();

        // Body shadow
        ctx.fillStyle = "rgba(0, 0, 0, 0.28)";
        ctx.beginPath();
        ctx.arc(patient.x, patient.y + 4, 10, 0, Math.PI * 2);
        ctx.fill();

        // Shirt
        ctx.fillStyle = "#ec4899"; // pink
        ctx.beginPath();
        ctx.roundRect(patient.x - 9, patient.y - 1, 18, 9, 4);
        ctx.fill();

        // Head
        ctx.fillStyle = "#fed7aa"; // skin tone
        ctx.beginPath();
        ctx.arc(patient.x, patient.y - 6, 6, 0, Math.PI * 2);
        ctx.fill();

        // Red emergency Cross above head
        ctx.strokeStyle = "#ef4444";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(patient.x - 4, patient.y - 14);
        ctx.lineTo(patient.x + 4, patient.y - 14);
        ctx.moveTo(patient.x, patient.y - 18);
        ctx.lineTo(patient.x, patient.y - 10);
        ctx.stroke();

        // Floating name + severity HUD above patient
        ctx.fillStyle = "#ef4444";
        ctx.beginPath();
        ctx.roundRect(patient.x - 30, patient.y - 34, 60, 14, 4);
        ctx.fill();

        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;
        ctx.strokeRect(patient.x - 30, patient.y - 34, 60, 14);

        ctx.fillStyle = "#ffffff";
        ctx.font = "9px monospace";
        ctx.textAlign = "center";
        ctx.fillText("SOS BOARD", patient.x, patient.y - 24);

        // Draw small dynamic health bar above patient
        const barWidth = 34;
        const barX = patient.x - barWidth / 2;
        const barY = patient.y + 16;
        ctx.fillStyle = "rgba(15, 23, 42, 0.75)";
        ctx.fillRect(barX, barY, barWidth, 4);

        ctx.fillStyle = patient.health < 35 ? "#ef4444" : (patient.health < 65 ? "#f59e0b" : "#10b981");
        ctx.fillRect(barX, barY, barWidth * (patient.health / 100), 4);

        // Name and severity tag
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 9px sans-serif";
        ctx.fillText(`${patient.name} (${patient.severity.toUpperCase()})`, patient.x, patient.y + 30);
      });

      // Draw Traffic Lights
      trafficLightsRef.current.forEach((tl) => {
        // Base box
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(tl.x - 8, tl.y - 20, 16, 40);
        
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(tl.x - 8, tl.y - 20, 16, 40);

        // Lights
        ctx.fillStyle = tl.state === "red" ? "#ef4444" : "rgba(239, 68, 68, 0.15)";
        ctx.beginPath();
        ctx.arc(tl.x, tl.y - 10, 4.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = tl.state === "yellow" ? "#f59e0b" : "rgba(245, 158, 11, 0.15)";
        ctx.beginPath();
        ctx.arc(tl.x, tl.y, 4.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = tl.state === "green" ? "#10b981" : "rgba(16, 185, 129, 0.15)";
        ctx.beginPath();
        ctx.arc(tl.x, tl.y + 10, 4.5, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Traffic Cars
      trafficCarsRef.current.forEach((car) => {
        ctx.save();
        ctx.translate(car.x, car.y);
        ctx.rotate(car.angle);

        // Car shadow
        ctx.fillStyle = "rgba(0,0,0,0.22)";
        ctx.fillRect(-car.width/2 + 2, -car.height/2 + 3, car.width, car.height);

        // Metallic chassis body
        ctx.fillStyle = car.color;
        ctx.beginPath();
        ctx.roundRect(-car.width/2, -car.height/2, car.width, car.height, 4);
        ctx.fill();

        // Wheels
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(-10, -car.height/2 - 2, 7, 2);
        ctx.fillRect(3, -car.height/2 - 2, 7, 2);
        ctx.fillRect(-10, car.height/2, 7, 2);
        ctx.fillRect(3, car.height/2, 7, 2);

        // Glass windows
        ctx.fillStyle = "rgba(15, 23, 42, 0.75)";
        ctx.fillRect(-4, -car.height/2 + 2, 10, car.height - 4);
        ctx.fillStyle = "rgba(255, 255, 255, 0.3)"; // highlight
        ctx.fillRect(0, -car.height/2 + 2, 2, car.height - 4);

        // Headlights glow
        ctx.fillStyle = "rgba(254, 240, 138, 0.6)";
        ctx.fillRect(car.width/2, -car.height/2 + 2, 3, 3);
        ctx.fillRect(car.width/2, car.height/2 - 5, 3, 3);

        // Headlight beams casting cone forwards
        const headlightCone = ctx.createLinearGradient(car.width/2, 0, car.width/2 + 55, 0);
        headlightCone.addColorStop(0, "rgba(254, 240, 138, 0.28)");
        headlightCone.addColorStop(1, "rgba(254, 240, 138, 0)");
        ctx.fillStyle = headlightCone;
        ctx.beginPath();
        ctx.moveTo(car.width/2, -5);
        ctx.lineTo(car.width/2 + 55, -25);
        ctx.lineTo(car.width/2 + 55, 25);
        ctx.lineTo(car.width/2, 5);
        ctx.closePath();
        ctx.fill();

        // Taillights
        ctx.fillStyle = car.braking ? "#ef4444" : "#991b1b";
        ctx.fillRect(-car.width/2 - 2, -car.height/2 + 2, 2, 2);
        ctx.fillRect(-car.width/2 - 2, car.height/2 - 4, 2, 2);

        ctx.restore();
      });

      // 11. DRAW PLAYER AMBULANCE WITH SELECTED SKIN
      ctx.save();
      ctx.translate(amb.x, amb.y);
      ctx.rotate(amb.angle);

      // Body shadow
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(-amb.width/2 + 3, -amb.height/2 + 4, amb.width, amb.height);

      // Determine colors based on active skin
      let primaryColor = "#f8fafc"; // White
      let stripeColor = "#dc2626";  // Red
      let roofColor = "#f1f5f9";
      let glassColor = "#0f172a";
      let glowColor: string | null = null;

      if (amb.skin === "cyber") {
        primaryColor = "#0d1b2a";
        stripeColor = "#06b6d4"; // Teal/Cyan neon
        roofColor = "#1e293b";
        glassColor = "#06b6d4";
        glowColor = "rgba(6, 182, 212, 0.35)";
      } else if (amb.skin === "stealth") {
        primaryColor = "#1e293b"; // Charcoal black
        stripeColor = "#64748b"; // Dark steel gray
        roofColor = "#0f172a";
        glassColor = "#ffffff";
        glowColor = "rgba(148, 163, 184, 0.18)";
      } else if (amb.skin === "gold") {
        primaryColor = "#d97706"; // Amber Gold
        stripeColor = "#fef08a"; // Platinum yellow
        roofColor = "#fbbf24";
        glassColor = "#fef08a";
        glowColor = "rgba(217, 119, 6, 0.4)";
      }

      // Neon Underglow if active
      if (glowColor) {
        ctx.shadowColor = stripeColor;
        ctx.shadowBlur = 15;
        ctx.fillStyle = glowColor;
        ctx.fillRect(-amb.width/2 - 4, -amb.height/2 - 4, amb.width + 8, amb.height + 8);
        ctx.shadowBlur = 0; // reset
      }

      // If invincible, flash opacity quickly
      if (amb.invincibleTime > 0 && Math.floor(time / 50) % 2 === 0) {
        ctx.globalAlpha = 0.4;
      }

      // Base solid chassis
      ctx.fillStyle = primaryColor;
      ctx.beginPath();
      ctx.roundRect(-amb.width/2, -amb.height/2, amb.width, amb.height, 4);
      ctx.fill();

      // Side styling stripe
      ctx.fillStyle = stripeColor;
      ctx.fillRect(-amb.width/2 + 2, -amb.height/2 + 3, amb.width - 4, 3);
      ctx.fillRect(-amb.width/2 + 2, amb.height/2 - 6, amb.width - 4, 3);

      // Wheels
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(-14, -amb.height/2 - 3, 9, 3);
      ctx.fillRect(5, -amb.height/2 - 3, 9, 3);
      ctx.fillRect(-14, amb.height/2, 9, 3);
      ctx.fillRect(5, amb.height/2, 9, 3);

      // Front bumper
      ctx.fillStyle = "#cbd5e1";
      ctx.fillRect(amb.width/2 - 3, -amb.height/2 + 4, 3, amb.height - 8);

      // Cabin roof top windshield
      ctx.fillStyle = roofColor;
      ctx.fillRect(-12, -amb.height/2 + 3, amb.width - 15, amb.height - 6);

      // Glass windshield
      ctx.fillStyle = glassColor;
      ctx.fillRect(6, -amb.height/2 + 4, 4, amb.height - 8); // main front glass
      ctx.fillRect(-8, -amb.height/2 + 4, 4, 2); // side glass left
      ctx.fillRect(-8, amb.height/2 - 6, 4, 2); // side glass right

      // Medical red cross logo on cabin roof
      ctx.fillStyle = stripeColor;
      const rx = -5;
      const ry = 0;
      ctx.fillRect(rx - 6, ry - 2, 12, 4);
      ctx.fillRect(rx - 2, ry - 6, 4, 12);

      // Headlights glow
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(amb.width/2 - 1, -amb.height/2 + 3, 2, 3);
      ctx.fillRect(amb.width/2 - 1, amb.height/2 - 6, 2, 3);

      // Premium Dual-Strobe Siren Lights
      const isRedPhase = Math.floor(sirenFlashRef.current / 4) % 2 === 0;
      
      // Draw sleek chrome mounting plate on the roof
      ctx.fillStyle = "#cbd5e1";
      ctx.fillRect(-12, -7, 3, 14);
      
      // Red Siren Dome (Left / Top in vehicle space)
      ctx.fillStyle = isRedPhase ? "#ef4444" : "#7f1d1d";
      ctx.beginPath();
      ctx.arc(-10.5, -4.5, 3, 0, Math.PI * 2);
      ctx.fill();
      
      // Blue Siren Dome (Right / Bottom in vehicle space)
      ctx.fillStyle = !isRedPhase ? "#3b82f6" : "#1e3a8a";
      ctx.beginPath();
      ctx.arc(-10.5, 4.5, 3, 0, Math.PI * 2);
      ctx.fill();

      // Atmospheric/volumetric glowing emergency lighting cast onto the road!
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      const flareRad = 135;
      if (isRedPhase) {
        // Red flare centered on Left dome
        const gradRed = ctx.createRadialGradient(-10.5, -4.5, 1, -10.5, -4.5, flareRad);
        gradRed.addColorStop(0, "rgba(239, 68, 68, 0.35)");
        gradRed.addColorStop(0.2, "rgba(239, 68, 68, 0.12)");
        gradRed.addColorStop(1, "rgba(239, 68, 68, 0)");
        ctx.fillStyle = gradRed;
        ctx.beginPath();
        ctx.arc(-10.5, -4.5, flareRad, 0, Math.PI * 2);
        ctx.fill();
        
        // Rotating red beacon beam sweep
        ctx.fillStyle = "rgba(239, 68, 68, 0.10)";
        ctx.beginPath();
        ctx.moveTo(-10.5, -4.5);
        const sweepAngle = (sirenFlashRef.current * 0.14) % (Math.PI * 2);
        ctx.arc(-10.5, -4.5, 190, sweepAngle - 0.32, sweepAngle + 0.32);
        ctx.closePath();
        ctx.fill();
      } else {
        // Blue flare centered on Right dome
        const gradBlue = ctx.createRadialGradient(-10.5, 4.5, 1, -10.5, 4.5, flareRad);
        gradBlue.addColorStop(0, "rgba(59, 130, 246, 0.35)");
        gradBlue.addColorStop(0.2, "rgba(59, 130, 246, 0.12)");
        gradBlue.addColorStop(1, "rgba(59, 130, 246, 0)");
        ctx.fillStyle = gradBlue;
        ctx.beginPath();
        ctx.arc(-10.5, 4.5, flareRad, 0, Math.PI * 2);
        ctx.fill();
        
        // Rotating blue beacon beam sweep
        ctx.fillStyle = "rgba(59, 130, 246, 0.10)";
        ctx.beginPath();
        ctx.moveTo(-10.5, 4.5);
        const sweepAngle = (sirenFlashRef.current * 0.14 + Math.PI) % (Math.PI * 2);
        ctx.arc(-10.5, 4.5, 190, sweepAngle - 0.32, sweepAngle + 0.32);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      ctx.restore(); // restore rotated ambulance state
      ctx.globalAlpha = 1.0;

      // 12. DRAW PARTICLES
      particlesRef.current.forEach((p) => {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        if (p.type === "heart") {
          // simple pixel heart shape
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.type === "plus") {
          // medical plus symbol
          ctx.fillRect(p.x - p.size, p.y - p.size/3, p.size * 2, p.size * 0.65);
          ctx.fillRect(p.x - p.size/3, p.y - p.size, p.size * 0.65, p.size * 2);
        } else {
          // normal smoke or spark circles
          ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      ctx.restore(); // restore absolute camera translations

      // 13. EXTRA TOP LAYER INTERFACE DRAW (E.G. SCREEN STROBE FLASH EFFECT ON DAMAGE)
      if (amb.invincibleTime > 75) {
        ctx.fillStyle = "rgba(220, 38, 38, 0.15)";
        ctx.fillRect(0, 0, dimensions.width, dimensions.height);
      }

      // Request next animation frame
      requestRef.current = requestAnimationFrame(gameLoop);
    };

    requestRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, score, lives, patientsRescued, timer, isMuted, activeSkin, upgrades, currentLevel, difficulty, dimensions, sirenMode]);

  // Handle minimap positioning and rendering inside separate useEffect or canvas drawer
  // Render clean GPS layout overlay
  return (
    <div 
      ref={containerRef} 
      id="canvas-container-box" 
      className="w-full h-full relative rounded-2xl overflow-hidden border-2 border-slate-800 shadow-2xl bg-slate-950 flex"
    >
      <canvas 
        ref={canvasRef} 
        id="game-canvas-element"
        width={dimensions.width} 
        height={dimensions.height}
        className="w-full h-full block"
      />

      {/* Siren Control Panel (bottom left overlay, positioned above speedometer) */}
      <div 
        id="siren-mode-overlay"
        className="absolute bottom-20 left-4 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-2xl p-2.5 font-mono flex flex-col gap-1.5 shadow-lg select-none min-w-[170px]"
      >
        <div className="flex items-center justify-between">
          <span className="text-[9px] text-slate-500 uppercase tracking-widest font-bold">Siren Tone</span>
          <span className="text-[8px] bg-rose-500/10 text-rose-400 border border-rose-500/25 rounded px-1 animate-pulse">Q / E</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            id="siren-quick-wail"
            onClick={() => onSirenModeChange("wail")}
            className={`px-1.5 py-1 text-[9px] font-bold rounded border transition-all cursor-pointer flex-1 text-center ${
              sirenMode === "wail" ? "bg-rose-500 border-rose-400 text-white font-black" : "bg-slate-900 border-slate-800 text-slate-450 hover:text-white hover:border-slate-700"
            }`}
            title="Wail - Slow USA Sweep"
          >
            WAIL
          </button>
          <button
            id="siren-quick-yelp"
            onClick={() => onSirenModeChange("yelp")}
            className={`px-1.5 py-1 text-[9px] font-bold rounded border transition-all cursor-pointer flex-1 text-center ${
              sirenMode === "yelp" ? "bg-rose-500 border-rose-400 text-white font-black" : "bg-slate-900 border-slate-800 text-slate-450 hover:text-white hover:border-slate-700"
            }`}
            title="Yelp - Urgent Sweep"
          >
            YELP
          </button>
          <button
            id="siren-quick-phaser"
            onClick={() => onSirenModeChange("phaser")}
            className={`px-1.5 py-1 text-[9px] font-bold rounded border transition-all cursor-pointer flex-1 text-center ${
              sirenMode === "phaser" ? "bg-rose-500 border-rose-400 text-white font-black" : "bg-slate-900 border-slate-800 text-slate-450 hover:text-white hover:border-slate-700"
            }`}
            title="Phaser - Hyper-fast Buzz"
          >
            PHAS
          </button>
          <button
            id="siren-quick-hilo"
            onClick={() => onSirenModeChange("hilo")}
            className={`px-1.5 py-1 text-[9px] font-bold rounded border transition-all cursor-pointer flex-1 text-center ${
              sirenMode === "hilo" ? "bg-rose-500 border-rose-400 text-white font-black" : "bg-slate-900 border-slate-800 text-slate-450 hover:text-white hover:border-slate-700"
            }`}
            title="Hi-Lo - Euro Two-Tone"
          >
            HILO
          </button>
        </div>
        <div className="flex items-center justify-between text-[8px] text-slate-500">
          <span>Active mode:</span>
          <span className="text-rose-400 font-bold uppercase">{sirenMode}</span>
        </div>
      </div>

      {/* Speedometer and Gear Indicators (bottom left overlay) */}
      <div 
        id="speedometer-overlay"
        className="absolute bottom-4 left-4 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-2xl px-4 py-3 font-mono flex items-center gap-3 shadow-lg select-none"
      >
        <div className="flex flex-col">
          <span className="text-[9px] text-slate-500 uppercase tracking-widest">Speedometer</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black text-white">{currentSpeedKmh}</span>
            <span className="text-xs text-rose-500 font-bold">KM/H</span>
          </div>
        </div>
        <div className="h-8 w-[1px] bg-slate-800" />
        <div className="flex flex-col items-center">
          <span className="text-[9px] text-slate-500 uppercase tracking-widest">Gear</span>
          <span className="text-sm font-black text-emerald-400">
            {currentSpeedKmh === 0 ? "N" : (keys.current["s"] || keys.current["arrowdown"] ? "R" : "D")}
          </span>
        </div>
      </div>

      {/* Floating HUD Warnings Alerts (top center overlay) */}
      {hudMessage && (
        <div 
          id="hud-toast" 
          className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-900/90 border border-rose-500/30 px-5 py-2.5 rounded-full shadow-xl flex items-center gap-2 max-w-sm text-center backdrop-blur-sm z-10 animate-fade-in-down"
        >
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping shrink-0" />
          <p className="text-xs font-bold text-slate-200 tracking-tight font-sans line-clamp-1">{hudMessage}</p>
        </div>
      )}

      {/* Dynamic Radar Gps Minimap (bottom right overlay) */}
      <div 
        id="gps-minimap" 
        className="absolute bottom-4 right-4 w-32 h-32 bg-slate-950/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col items-center justify-center p-1 select-none"
      >
        <div className="w-full text-[9px] font-mono text-slate-500 text-center uppercase tracking-widest mb-1">
          GPS NAV RADAR
        </div>
        <div className="relative w-[100px] h-[100px] bg-slate-900 rounded-full border border-slate-800 overflow-hidden flex items-center justify-center">
          {/* Radar Sweep line animation */}
          <div className="absolute inset-0 border border-slate-800/40 rounded-full" />
          <div className="absolute w-[60px] h-[60px] border border-slate-800/20 rounded-full" />
          <div className="absolute w-[20px] h-[20px] border border-slate-800/10 rounded-full" />
          <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-slate-800/30" />
          <div className="absolute left-0 right-0 top-1/2 h-[1px] bg-slate-800/30" />

          {/* Minimap content wrapper scaled from 1600x1600 to 100x100 (scale: 0.0625) */}
          {/* Hospital indicator (Green Center Point) */}
          <div 
            className="absolute w-3.5 h-3.5 bg-emerald-500 text-white rounded font-bold text-[8px] flex items-center justify-center shadow-lg animate-pulse"
            style={{ 
              left: `${(HOSPITAL_ZONE.x + HOSPITAL_ZONE.width/2) * 0.0625 - 7}px`, 
              top: `${(HOSPITAL_ZONE.y + HOSPITAL_ZONE.height/2) * 0.0625 - 7}px` 
            }}
            title="Hospital Bay"
          >
            +
          </div>

          {/* Patient indicators (Red pulsing dots) */}
          {patientsRef.current.map((patient) => {
            if (patient.pickedUp || patient.health <= 0) return null;
            return (
              <div 
                key={patient.id}
                className="absolute w-2 h-2 bg-red-500 rounded-full border border-white animate-ping"
                style={{ 
                  left: `${patient.x * 0.0625 - 4}px`, 
                  top: `${patient.y * 0.0625 - 4}px` 
                }}
              />
            );
          })}

          {/* Active ambulance indicator (White rotated pointer arrow) */}
          <div 
            className="absolute w-3 h-3 bg-white shadow-md border border-slate-950 flex items-center justify-center"
            style={{ 
              left: `${ambulanceRef.current.x * 0.0625 - 6}px`, 
              top: `${ambulanceRef.current.y * 0.0625 - 6}px`,
              transform: `rotate(${ambulanceRef.current.angle}rad)`,
              clipPath: "polygon(100% 50%, 0 0, 25% 50%, 0 100%)" // wedge arrow shape
            }}
          />
        </div>
      </div>
    </div>
  );
};
